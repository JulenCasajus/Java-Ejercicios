package ejer1;

public class SinglyLinkedList<T> {
	
	private Node<T> first;
	
	public SinglyLinkedList() {
	}
	
	//pre: Al menos hay un elemento en la lista
	//pre: 0 <= p < numero elementos
	public void saltar(int p) {
		
		Node<T> actual = first;
		Node<T> aux = first;
		
		for(int i = 0; i < p; i++) {
			actual = actual.next;
		}
		
		if(p != 0) {
			first = first.next;
			aux.next = actual.next;
			actual.next = aux;
		}
	}
	
	//METODOS PARA PRUEBAS (NO MODIFICAR)
	
	public void anadirNodoAlPrincipio(T valor) {
		Node<T> nodo = new Node<T>();
		nodo.info = valor;
		if(first == null) {
			this.first = nodo;
		} else {
			nodo.next = first;
			first = nodo;
		}
	}
	
	@Override
   public String toString() {
	   String res = "";
	   Node<T> aux = first;
	   while(aux != null) {
		   res = res + aux.info + " ";
		   aux = aux.next;
	   }
	   return res;
   }
}