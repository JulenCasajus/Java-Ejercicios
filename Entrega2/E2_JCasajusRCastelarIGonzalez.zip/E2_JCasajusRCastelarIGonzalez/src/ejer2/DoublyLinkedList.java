package ejer2;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class DoublyLinkedList<T extends Comparable<T>> implements Iterable<T>  {

	private Node<T> first;
	private Node<T> last;

	
	public DoublyLinkedList() {

	}

	
public T removeLastAppearance(T elem) {
		
		/*if (first == last && first.info == elem) {
			first = null;
			last = null;
			return elem;
		}
		
		if (first == last && first.info != elem) return null;
		
		Node<T> derecha = last;
		Node<T> izquierda = first;
		Node<T> aparicion = null;
		
		while (derecha.prev != izquierda && derecha != izquierda && derecha.info != elem) {
			if (derecha.info == elem) aparicion = derecha;
			else if (izquierda.info == elem) aparicion = izquierda;
			derecha = derecha.prev;
			izquierda = izquierda.next;
		}
		if (aparicion == derecha || derecha.info == elem) {			
			if (derecha.next != null) {
				Node<T> derechaNext = derecha.next;
				Node<T> derechaPrev = derecha.prev;
				derechaPrev.next = derechaNext;
				derechaNext.prev = derechaPrev;
				derecha.next = null;
				derecha.prev = null;
				return elem;
			}
			else if(derecha.next == null) {
				Node<T> derechaPrev = derecha.prev;
				last = derechaPrev;
				derechaPrev.next = null;
				derecha.prev = null;
				return elem;
			}			
		}
		else if (izquierda.info == elem) {
			Node<T> izquierdaPrev = izquierda.prev;
			Node<T> izquierdaNext = izquierda.next;
			izquierdaPrev.next = izquierdaNext;
			izquierdaNext.prev = izquierdaPrev;
			izquierda.next = null;
			izquierda.prev = null;
			return elem;
		}
		else if (aparicion != null) {
			if (aparicion.prev == null) {
				first = aparicion.next;
				aparicion.next = null;
				return elem;
			}
			else {
				Node<T> aparicionNext = aparicion.next;
				Node<T> aparicionPrev = aparicion.prev;
				aparicionPrev.next = aparicionNext;
				aparicionNext.prev = aparicionPrev;
				aparicion.prev = null;
				aparicion.next = null;
				return elem;
			}
		}	
		return null;*/
	
	Node<T> izq = first;
	Node<T> der = last;
	Node<T> aux = null;
	
    while (izq != der && der.next != izq && der.info != elem) {
    	
        if (izq.info == elem) aux = izq;
        izq = izq.next;
        der = der.prev;
    }
    
    if(der.info == elem) {
	    
    	if (der == first) {
	        first = last = null; //1 elemento en la lista y coincide
	    } else if (der == last) { //ultimo elemento coincide
	    	last = der.prev;
	        last.next = null;
	    } else { //elemento en parte derecha coincide
	        der.prev.next = der.next;
	        der.next.prev = der.prev;
	    }
	    return der.info;
	    
    } else if(aux != null) { //elemento en parte izquierda coincide
    	
    	if (aux == first) { //primer elemento coincide
	    	first = aux.next;
	        first.prev = null;
	    } else { //elemento en parte izquierda coincide
	        aux.prev.next = aux.next;
	        aux.next.prev = aux.prev;
	    }
	    return aux.info;
    }
    return null; //elemento no encontrado
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
    ///////// AUXILIARES PARA PRUEBAS (NO MODIFICAR) ////////////////////
	
	
	
	//Returns a string representation of this collection. The string representation
    // consists of a list of the collection's elements, enclosed in square 
    // brackets ("[]"). Adjacent elements are separated by the characters ", " 
    // (comma and space). 
	@Override
	public String toString() {
	    Node<T> actual = first;
	    String resultado = "[";
	    while(actual!=null) {
	    	resultado += actual.info.toString();
	    	if(actual!=last) resultado+=", ";
	    	actual=actual.next;
	    }
	    resultado+="]";
		return resultado;
	}
	
	//Imprime la lista pero al rev�s.
	public String toStringPeroAlReves() {
		
	    Node<T> actual = last;
	    String resultado = "[";
	    while(actual!=null) {
	    	resultado += actual.info.toString();
	    	if(actual!=first) resultado+=", ";
	    	actual=actual.prev;
	    }
	    resultado+="]";
		return resultado;
	}
	
	public void addLast(T elem) {
		Node<T> newNode = new Node<T>(elem);
		if (first==null) {
            first = newNode;
            last = newNode;
        } else {
            newNode.prev = last;
            last.next = newNode;
            last = newNode;
        }
	}
	
	@Override
    public Iterator<T> iterator() {
        return new IteradorLista();
    }

    // Clase interna para el iterador
    private class IteradorLista implements Iterator<T> {
        private Node<T> actual = first;

        @Override
        public boolean hasNext() {
            return actual != null;
        }

        @Override
        public T next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }
            T dato = actual.info;
            actual = actual.next;
            return dato;
        }
    }
    
    public Iterator<T> reverseIterator() {
        return new ReverseIterator();
    }

    // Clase interna para el iterador inverso
    private class ReverseIterator implements Iterator<T> {
        private Node<T> current = last;

        @Override
        public boolean hasNext() {
            return current != null;
        }

        @Override
        public T next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }
            T data = current.info;
            current = current.prev;
            return data;
        }
    }
	

}
