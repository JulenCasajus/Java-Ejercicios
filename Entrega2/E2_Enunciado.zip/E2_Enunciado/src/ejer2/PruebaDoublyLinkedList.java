package ejer2;


public class PruebaDoublyLinkedList {
	

	public PruebaDoublyLinkedList() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		
		
		DoublyLinkedList<Integer> lista = new DoublyLinkedList<Integer>();
		
		Integer[] nums = {2,4,1,4,7,6};
		
		for(Integer n:nums) {
			lista.addLast(n);
		}
		
		System.out.println("Lista inicial: "+lista);
		Integer eliminado = lista.removeLastAppearance(4);
		System.out.println("Elemento eliminado: "+eliminado);
		System.out.println("Lista modificada: "+lista);		

		



	}
}
