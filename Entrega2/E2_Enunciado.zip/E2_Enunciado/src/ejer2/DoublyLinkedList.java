package ejer2;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class DoublyLinkedList<T extends Comparable<T>> implements Iterable<T>  {

	private Node<T> first;
	private Node<T> last;

	
	public DoublyLinkedList() {

	}

	
	public T removeLastAppearance(T elem) {
		
		return null; //CORREGIR SI NECESARIO
	}
	
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
    ///////// AUXILIARES PARA PRUEBAS (NO MODIFICAR) ////////////////////
	
	
	
	//Returns a string representation of this collection. The string representation
    // consists of a list of the collection's elements, enclosed in square 
    // brackets ("[]"). Adjacent elements are separated by the characters ", " 
    // (comma and space). 
	@Override
	public String toString() {
	    Node<T> actual = first;
	    String resultado = "[";
	    while(actual!=null) {
	    	resultado += actual.info.toString();
	    	if(actual!=last) resultado+=", ";
	    	actual=actual.next;
	    }
	    resultado+="]";
		return resultado;
	}
	
	//Imprime la lista pero al rev�s.
	public String toStringPeroAlReves() {
		
	    Node<T> actual = last;
	    String resultado = "[";
	    while(actual!=null) {
	    	resultado += actual.info.toString();
	    	if(actual!=first) resultado+=", ";
	    	actual=actual.prev;
	    }
	    resultado+="]";
		return resultado;
	}
	
	public void addLast(T elem) {
		Node<T> newNode = new Node<T>(elem);
		if (first==null) {
            first = newNode;
            last = newNode;
        } else {
            newNode.prev = last;
            last.next = newNode;
            last = newNode;
        }
	}
	
	@Override
    public Iterator<T> iterator() {
        return new IteradorLista();
    }

    // Clase interna para el iterador
    private class IteradorLista implements Iterator<T> {
        private Node<T> actual = first;

        @Override
        public boolean hasNext() {
            return actual != null;
        }

        @Override
        public T next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }
            T dato = actual.info;
            actual = actual.next;
            return dato;
        }
    }
    
    public Iterator<T> reverseIterator() {
        return new ReverseIterator();
    }

    // Clase interna para el iterador inverso
    private class ReverseIterator implements Iterator<T> {
        private Node<T> current = last;

        @Override
        public boolean hasNext() {
            return current != null;
        }

        @Override
        public T next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }
            T data = current.info;
            current = current.prev;
            return data;
        }
    }
	

}
