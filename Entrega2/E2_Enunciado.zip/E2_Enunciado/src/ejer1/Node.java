package ejer1;

public class Node<T> {
	
	T info;
	Node<T> next;

	public Node() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
