package ejer1;

public class PruebaSaltar {

	public PruebaSaltar() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
       
		
		System.out.println("### Prueba 1 ###");
		SinglyLinkedList<Character> lista1 = new SinglyLinkedList<Character>();
		lista1.anadirNodoAlPrincipio('D');
		lista1.anadirNodoAlPrincipio('C');
		lista1.anadirNodoAlPrincipio('B');
		lista1.anadirNodoAlPrincipio('A');
		System.out.println("Lista original: "+lista1.toString());
		lista1.saltar(2);
		System.out.println("Tras hacer salto con p=2: "+lista1.toString());
		
		System.out.println("\n### Prueba 2 ###");
		SinglyLinkedList<Character> lista2 = new SinglyLinkedList<Character>();
		lista2.anadirNodoAlPrincipio('D');
		lista2.anadirNodoAlPrincipio('C');
		lista2.anadirNodoAlPrincipio('B');
		lista2.anadirNodoAlPrincipio('A');
		System.out.println("Lista original: "+lista2.toString());
		lista2.saltar(0);
		System.out.println("Tras hacer salto con p=0: "+lista2.toString());

	}

}
