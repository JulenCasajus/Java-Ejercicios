package ejer1;

public class PruebaEjer1 {

	public static void main(String[] args) {
		
		NodoCasilla n11 = new NodoCasilla(new Casilla(11,true));
		NodoCasilla n5 = new NodoCasilla(new Casilla(5,true));
		NodoCasilla n13 = new NodoCasilla(new Casilla(13,false));
		NodoCasilla n9 = new NodoCasilla(new Casilla(9,false));
		NodoCasilla n8 = new NodoCasilla(new Casilla(8,true));
		NodoCasilla n7 = new NodoCasilla(new Casilla(7,false));
		NodoCasilla n1 = new NodoCasilla(new Casilla(1,true));
		NodoCasilla n3 = new NodoCasilla(new Casilla(3,false));
		NodoCasilla n4 = new NodoCasilla(new Casilla(4,true));
		NodoCasilla n17 = new NodoCasilla(new Casilla(17,false));
		NodoCasilla n12 = new NodoCasilla(new Casilla(12,false));
		NodoCasilla n20 = new NodoCasilla(new Casilla(20,true));
		
		GrafoCasillas g = new GrafoCasillas();
		g.getCasillas().add(n11);
		g.getCasillas().add(n5);
		g.getCasillas().add(n13);
		g.getCasillas().add(n9);
		g.getCasillas().add(n8);
		g.getCasillas().add(n7);
		g.getCasillas().add(n1);
		g.getCasillas().add(n3);
		g.getCasillas().add(n4);
		g.getCasillas().add(n17);
		g.getCasillas().add(n12);
		g.getCasillas().add(n20);
		
		g.setNumVertices(g.getCasillas().size());
		
		n11.anadirCasilla(n5);
		n11.anadirCasilla(n13);
		
		n5.anadirCasilla(n9);
		n5.anadirCasilla(n8);
		n5.anadirCasilla(n13);
		
		n13.anadirCasilla(n8);
		
		n8.anadirCasilla(n9);
		
		n9.anadirCasilla(n1);
		n9.anadirCasilla(n3);
		n9.anadirCasilla(n12);
		n9.anadirCasilla(n7);
		
		n7.anadirCasilla(n12);
		
		n3.anadirCasilla(n1);
		n3.anadirCasilla(n17);
		n3.anadirCasilla(n12);
		n3.anadirCasilla(n4);
		
		n12.anadirCasilla(n17);
		n12.anadirCasilla(n20);
		
		n1.anadirCasilla(n4);
		n1.anadirCasilla(n17);
		
		n17.anadirCasilla(n20);
		n17.anadirCasilla(n4);
		
		n4.anadirCasilla(n20);
		
		System.out.println(g.camino(n11, n20));

	}

}
