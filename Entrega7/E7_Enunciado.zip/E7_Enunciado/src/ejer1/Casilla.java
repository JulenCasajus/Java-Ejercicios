package ejer1;

public class Casilla {
	
	private boolean esBlanca;
	private int valor;
	
	public boolean getEsBlanca() {
		return esBlanca;
	}



	public int getValor() {
		return valor;
	}

	

	public Casilla(int valor, boolean esBlanca) {
		this.valor = valor;
		this.esBlanca = esBlanca;
	}

}
