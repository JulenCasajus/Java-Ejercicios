package ejer1;

import java.util.ArrayList;
import java.util.LinkedList;

public class GrafoCasillas {
	private int numVertices;
	private ArrayList<NodoCasilla> casillas;
	
	public GrafoCasillas() {
		this.numVertices = 0;
		this.casillas = new ArrayList<NodoCasilla>();
	}
	
	public int getNumVertices() {
		return numVertices;
	}

	public void setNumVertices(int numVertices) {
		this.numVertices = numVertices;
	}	

	public ArrayList<NodoCasilla> getCasillas() {
		return casillas;
	}


	
	//Pre: origen y destino est�n en el grafo 
	public LinkedList<Integer> camino(NodoCasilla origen, NodoCasilla destino){

		//TO DO

		return null; //CORREGIR SI NECESARIO
		
		
	}



}
