package ejer2;

import java.util.ArrayList;
import java.util.LinkedList;


public class GrafoCiudades {
	
	private int numVertices; // n� de nodos del grafo
	private LinkedList<NodoCiudad> ciudades;
	
	public GrafoCiudades() {
		this.numVertices = 0;
		this.ciudades = new LinkedList<NodoCiudad>();
	}

	public ArrayList<CiudadEIntensidad> ciudadesAfectadas(String nomCiudad, float intensidad){
		
		//TO DO
		return null; //CORREGIR SI NECESARIO
	}
	

	
	
	
	
	//AUXILIARES PARA PRUEBAS
	
	
	public void anadirArista(NodoCiudad origen, NodoCiudad destino) {
		
		NodoCiudad c1 = buscar(origen.getNombre());
		if(c1==null) anadirNodo(origen);
		NodoCiudad c2 = buscar(destino.getNombre());
		if(c2==null) anadirNodo(destino);
		
		origen.getAdyacentes().add(destino);
		destino.getAdyacentes().add(origen);
		
	}
	
	//Pre: nodo no est� en el grafo
	private void anadirNodo(NodoCiudad nodo) {
		this.ciudades.add(nodo);
		this.numVertices++;
	}
	
	private NodoCiudad buscar(String nombre) {
		for(NodoCiudad nodo:ciudades) {
			if(nodo.getNombre().equals(nombre)) return nodo;
		}
		return null;
	}

}
