package ejer2;

import java.util.ArrayList;

public class PruebaEjer2 {

	public PruebaEjer2() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		
		GrafoCiudades g = new GrafoCiudades();

		NodoCiudad nodoA = new NodoCiudad("A");
		NodoCiudad nodoB = new NodoCiudad("B");
		NodoCiudad nodoC = new NodoCiudad("C");
		NodoCiudad nodoD = new NodoCiudad("D");
		NodoCiudad nodoE = new NodoCiudad("E");
		NodoCiudad nodoG = new NodoCiudad("G");
		NodoCiudad nodoH = new NodoCiudad("H");
		NodoCiudad nodoK = new NodoCiudad("K");
		NodoCiudad nodoL = new NodoCiudad("L");
		NodoCiudad nodoM = new NodoCiudad("M");
		NodoCiudad nodoN = new NodoCiudad("N");
		NodoCiudad nodoO = new NodoCiudad("O");
		NodoCiudad nodoP = new NodoCiudad("P");
		NodoCiudad nodoQ = new NodoCiudad("Q");
		NodoCiudad nodoR = new NodoCiudad("R");
		NodoCiudad nodoS = new NodoCiudad("S");
		NodoCiudad nodoT = new NodoCiudad("T");
		NodoCiudad nodoV = new NodoCiudad("V");
		NodoCiudad nodoW = new NodoCiudad("W");
		NodoCiudad nodoX = new NodoCiudad("X");
		NodoCiudad nodoY = new NodoCiudad("Y");

		
		g.anadirArista(nodoK, nodoH);
		g.anadirArista(nodoV, nodoL);
		g.anadirArista(nodoQ, nodoD);
		g.anadirArista(nodoA, nodoH);
		g.anadirArista(nodoA, nodoT);
		g.anadirArista(nodoW, nodoT);
		g.anadirArista(nodoC, nodoT);
		g.anadirArista(nodoC, nodoY);
		g.anadirArista(nodoC, nodoX);
		g.anadirArista(nodoL, nodoT);
		g.anadirArista(nodoS, nodoV);
		g.anadirArista(nodoS, nodoB);
		g.anadirArista(nodoL, nodoE);
		g.anadirArista(nodoQ, nodoE);
		g.anadirArista(nodoP, nodoE);
		g.anadirArista(nodoM, nodoE);
		g.anadirArista(nodoO, nodoM);
		g.anadirArista(nodoO, nodoP);
		g.anadirArista(nodoR, nodoM);
		g.anadirArista(nodoR, nodoG);
		g.anadirArista(nodoQ, nodoN);
		
		
		System.out.println("\n### PRUEBA 1 ###");
		System.out.print("Ciudades afectadas por un terremoto de intensidad 6 en L: ");
		ArrayList<CiudadEIntensidad> ar1 = g.ciudadesAfectadas("L", 6.0f);
		System.out.println(ar1);
		
		System.out.println("\n### PRUEBA 2 ###");
		System.out.print("Ciudades afectadas por un terremoto de intensidad 2 en H: ");
		ArrayList<CiudadEIntensidad> ar2 = g.ciudadesAfectadas("H", 2.0f);
		System.out.println(ar2);
		
		System.out.println("\n### PRUEBA 3 ###");
		System.out.print("Ciudades afectadas por un terremoto de intensidad 8.5 en Q: ");
		ArrayList<CiudadEIntensidad> ar3 = g.ciudadesAfectadas("Q", 8.5f);
		System.out.println(ar3);
		
		System.out.println("\n### PRUEBA 4 ###");
		System.out.print("Ciudades afectadas por un terremoto de intensidad 0.8 en L: ");
		ArrayList<CiudadEIntensidad> ar4 = g.ciudadesAfectadas("L", 0.8f);
		System.out.println(ar4);
		

	}

}
