package ejer2;

public class CiudadEIntensidad {
	
	private String nombre; //nombre de la ciudad
	private float  intensidad; //intensidad con la que es afectada

	public CiudadEIntensidad(String nombre, float intensidad) {
		this.nombre = nombre;
		this.intensidad = intensidad;
	}

	public float getIntensidad() {
		return intensidad;
	}

	public void setIntensidad(float intensidad) {
		this.intensidad = intensidad;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	@Override
	public String toString() {
		return nombre+": "+intensidad;
	}
	
	

}
