package ejer2;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.HashMap;

public class GrafoCiudades {
	
	private int numVertices; // numero de nodos del grafo
	private LinkedList<NodoCiudad> ciudades;
	
	public GrafoCiudades() {
		this.numVertices = 0;
		this.ciudades = new LinkedList<NodoCiudad>();
	}

	public ArrayList<CiudadEIntensidad> ciudadesAfectadas(String nomCiudad, float intensidad) {
		
		float intens = intensidad;
		NodoCiudad aux = null;
		Queue<NodoCiudad> cola = new LinkedList<>();
		HashMap<NodoCiudad, Float> visitados = new HashMap<>();
		ArrayList<CiudadEIntensidad> lista = new ArrayList<>();

		for(int i = 0; i < numVertices; i++) {
			if(ciudades.get(i).getNombre().equals(nomCiudad)) aux = ciudades.get(i);
		}
		
		if(aux == null) return new ArrayList<CiudadEIntensidad>();
		
		if(intensidad > 1) {
			lista.add(new CiudadEIntensidad(aux.getNombre(), intensidad));
			visitados.put(aux, intensidad);
			cola.add(aux);
			while(!cola.isEmpty()) {
				aux = cola.remove();
				intens = visitados.get(aux)/2;
				if(intens >= 1) {
					for(NodoCiudad ady : aux.getAdyacentes()) {
						if(!visitados.containsKey(ady)) {
							cola.add(ady);
							visitados.put(ady, intens);
							lista.add(new CiudadEIntensidad(ady.getNombre(), intens));
						}
					}
				}
			}
		}
		return lista;
	}
	
	//AUXILIARES PARA PRUEBAS
	
	public void anadirArista(NodoCiudad origen, NodoCiudad destino) {
		
		NodoCiudad c1 = buscar(origen.getNombre());
		if(c1 == null) anadirNodo(origen);
		NodoCiudad c2 = buscar(destino.getNombre());
		if(c2 == null) anadirNodo(destino);
		
		origen.getAdyacentes().add(destino);
		destino.getAdyacentes().add(origen);
	}
	
	//Pre: nodo no esta en el grafo
	private void anadirNodo(NodoCiudad nodo) {
		this.ciudades.add(nodo);
		this.numVertices++;
	}
	
	private NodoCiudad buscar(String nombre) {
		for(NodoCiudad nodo:ciudades) {
			if(nodo.getNombre().equals(nombre)) return nodo;
		}
		return null;
	}
}