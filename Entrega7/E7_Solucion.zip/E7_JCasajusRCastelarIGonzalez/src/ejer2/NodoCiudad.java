package ejer2;

import java.util.LinkedList;

public class NodoCiudad {
	
	private String nombre; //nombre de la ciudad
	private LinkedList<NodoCiudad> adyacentes;

	public NodoCiudad(String nombre) {
		this.nombre = nombre;
		this.adyacentes = new LinkedList<NodoCiudad>();
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public LinkedList<NodoCiudad> getAdyacentes(){
		return this.adyacentes;
	}
}