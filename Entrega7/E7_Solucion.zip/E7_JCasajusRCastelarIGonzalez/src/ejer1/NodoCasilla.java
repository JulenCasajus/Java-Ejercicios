package ejer1;

import java.util.LinkedList;

public class NodoCasilla {
	Casilla info;
	LinkedList<NodoCasilla> adyacentes;

	public NodoCasilla(Casilla info) {
		this.info = info;
		this.adyacentes=new LinkedList<NodoCasilla>();
	}
	
	public void anadirCasilla(NodoCasilla adyacente) {
		this.adyacentes.add(adyacente);
		adyacente.adyacentes.add(this);
	}
}