package ejer1;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.HashMap;

public class GrafoCasillas {
	private int numVertices;
	private ArrayList<NodoCasilla> casillas;
	
	public GrafoCasillas() {
		this.numVertices = 0;
		this.casillas = new ArrayList<NodoCasilla>();
	}
	
	public int getNumVertices() {
		return numVertices;
	}

	public void setNumVertices(int numVertices) {
		this.numVertices = numVertices;
	}	

	public ArrayList<NodoCasilla> getCasillas() {
		return casillas;
	}

	//Pre: origen y destino estan en el grafo 
	public LinkedList<Integer> camino(NodoCasilla origen, NodoCasilla destino) {
		LinkedList<NodoCasilla> cola = new LinkedList<>();
	    HashMap<NodoCasilla, NodoCasilla> visitadoYPrevio = new HashMap<>();
	    LinkedList<Integer> camino = new LinkedList<>();
	
		NodoCasilla aux;
		
		cola.add(origen);
		visitadoYPrevio.put(origen, null);
		
		while(!cola.isEmpty()) {
			aux = cola.remove();

			for(NodoCasilla adyacente : aux.adyacentes) {
				if(!visitadoYPrevio.containsKey(adyacente) && aux.info.getEsBlanca() != adyacente.info.getEsBlanca()) {
					cola.add(adyacente);
					visitadoYPrevio.put(adyacente, aux);

					if(adyacente.equals(destino)) {
						while(visitadoYPrevio.get(adyacente) != null) {
							camino.addFirst(adyacente.info.getValor());
							adyacente = visitadoYPrevio.get(adyacente);
						}
						camino.addFirst(adyacente.info.getValor());
						return camino;
					}
				}
			}
		}
		return camino;
	}
}