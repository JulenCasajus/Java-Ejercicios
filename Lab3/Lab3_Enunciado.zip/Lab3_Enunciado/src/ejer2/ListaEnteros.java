package ejer2;

public class ListaEnteros {
	NodoEnteros first;
	NodoEnteros last;

	public ListaEnteros() {
		// TODO Auto-generated constructor stub
	}
	

	
	public void eliminarNegativosConPositivo() {
		//TO DO
	}
	
	

    //Para pruebas:
	
	public void imprimirAlDerecho() {
		System.out.println("Lista al derecho:");
		NodoEnteros aux = first;
		while(aux!=null) {
			System.out.print(aux.info+" ");
			aux = aux.next;
		}
		System.out.println();
	}
	
	public void imprimirAlReves() {
		System.out.println("Lista al reves:");
		NodoEnteros aux = last;
		while(aux!=null) {
			System.out.print(aux.info+" ");
			aux = aux.prev;
		}
		System.out.println();
	}
	
	public void addLast(int info) {
		NodoEnteros nuevo = new NodoEnteros(info);
		if(first==null) {
			first = nuevo;
			last = nuevo;
		}else {
			nuevo.prev = last;
			last.next = nuevo;
			last = nuevo;
		}
	}


}
