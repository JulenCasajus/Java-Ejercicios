package ejer1;

public class PruebaMyOrderedLinkedList {

	public PruebaMyOrderedLinkedList() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		//Lista de strings
		MyOrderedLinkedList<String> lista = new MyOrderedLinkedList<String>();
		System.out.println("Lista inicial:");
		System.out.println("Al derecho: "+lista.toString());
		System.out.println("Al reves: "+lista.toStringPeroAlReves()+"\n");
		
		System.out.println("Añado ojo:");
		lista.addOrdered("ojo");
		System.out.println("Al derecho: "+lista.toString());
		System.out.println("Al reves: "+lista.toStringPeroAlReves()+"\n");
	
		
		System.out.println("Añado casa:");
		lista.addOrdered("casa");
		System.out.println("Al derecho: "+lista.toString());
		System.out.println("Al reves: "+lista.toStringPeroAlReves()+"\n");
		
		
		System.out.println("Añado parque:");
		lista.addOrdered("parque");
		System.out.println("Al derecho: "+lista.toString());
		System.out.println("Al reves: "+lista.toStringPeroAlReves()+"\n");
		
		
		System.out.println("Añado ojo:");
		lista.addOrdered("ojo");
		System.out.println("Al derecho: "+lista.toString());
		System.out.println("Al reves: "+lista.toStringPeroAlReves()+"\n");
		
		System.out.println("Añado arbol:");
		lista.addOrdered("arbol");
		System.out.println("Al derecho: "+lista.toString());
		System.out.println("Al reves: "+lista.toStringPeroAlReves()+"\n");
		
		
		System.out.println("Añado zapato:");
		lista.addOrdered("zapato");
		System.out.println("Al derecho: "+lista.toString());
		System.out.println("Al reves: "+lista.toStringPeroAlReves()+"\n");
		
		System.out.println("Añado verdad:");
		lista.addOrdered("verdad");
		System.out.println("Al derecho: "+lista.toString());
		System.out.println("Al reves: "+lista.toStringPeroAlReves()+"\n");
		
		
				


	}

}
