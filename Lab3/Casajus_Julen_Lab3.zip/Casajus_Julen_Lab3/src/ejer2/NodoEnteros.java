package ejer2;

public class NodoEnteros {	
	int info;
	NodoEnteros prev;
	NodoEnteros next;

	public NodoEnteros(int info) {
		this.info = info;
	}
}