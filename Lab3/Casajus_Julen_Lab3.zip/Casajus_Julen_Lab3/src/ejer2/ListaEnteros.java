package ejer2;

public class ListaEnteros {
	NodoEnteros first;
	NodoEnteros last;

	public ListaEnteros() {
		// TODO Auto-generated constructor stub
	}

	public void eliminarNegativosConPositivo() {
		if(first == null) return;
		NodoEnteros Aux1 = first, Aux2 = last;
		while(Aux1 != null && Aux2 != null && Aux1.info < 0 && Aux2.info >0) {
			if(-Aux1.info == Aux2.info) {
				if(Aux1 == first) {
					first = first.next;
					first.prev = null;
				} else {
					Aux1.prev.next = Aux1.next;
					Aux1.next.prev = Aux1.prev;
				}
				Aux1 = Aux1.next;
				Aux2 = Aux2.prev;
			} else if(-Aux1.info > Aux2.info) {
				Aux1 = Aux1.next;
			} else {
				Aux2 = Aux2.prev;
			}
		}
	}	
	
	//METODOS AUXILIARES PARA PRUEBAS
	
	public void imprimirAlDerecho() {
		System.out.println("Lista al derecho:");
		NodoEnteros aux = first;
		while(aux != null) {
			System.out.print(aux.info + " ");
			aux = aux.next;
		}
		System.out.println();
	}
	
	public void imprimirAlReves() {
		System.out.println("Lista al reves:");
		NodoEnteros aux = last;
		while(aux != null) {
			System.out.print(aux.info + " ");
			aux = aux.prev;
		}
		System.out.println();
	}
	
	public void addLast(int info) {
		NodoEnteros nuevo = new NodoEnteros(info);
		if(first == null) {
			first = nuevo;
			last = nuevo;
		} else {
			nuevo.prev = last;
			last.next = nuevo;
			last = nuevo;
		}
	}
}