package ejer2;

public class PruebaListaEnteros {

	public PruebaListaEnteros() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		ListaEnteros l = new ListaEnteros();
		l.addLast(-8);
		l.addLast(-5);
		l.addLast(-4);
		l.addLast(-2);
		l.addLast(-1);
		l.addLast(2);
		l.addLast(3);
		l.addLast(4);
		System.out.println("Prueba #1:");
		l.imprimirAlDerecho();
		System.out.println("Tras eliminar negativos que tienen positivo:");
		l.eliminarNegativosConPositivo();
		l.imprimirAlDerecho();
		l.imprimirAlReves();
		
		ListaEnteros l2 = new ListaEnteros();
		l2.addLast(-3);
		l2.addLast(-2);
		l2.addLast(2);
		l2.addLast(3);
		System.out.println("\nPrueba #2:");
		l2.imprimirAlDerecho();
		System.out.println("Tras eliminar negativos que tienen positivo:");
		l2.eliminarNegativosConPositivo();
		l2.imprimirAlDerecho();
		l2.imprimirAlReves();
		
		ListaEnteros l3 = new ListaEnteros();
		l3.addLast(-3);
		l3.addLast(-2);
		l3.addLast(-1);
		System.out.println("\nPrueba #3:");
		l3.imprimirAlDerecho();
		System.out.println("Tras eliminar negativos que tienen positivo:");
		l3.eliminarNegativosConPositivo();
		l3.imprimirAlDerecho();
		l3.imprimirAlReves();
		
		ListaEnteros l4 = new ListaEnteros();
		l4.addLast(4);
		l4.addLast(6);
		l4.addLast(9);
		System.out.println("\nPrueba #4:");
		l4.imprimirAlDerecho();
		System.out.println("Tras eliminar negativos que tienen positivo:");
		l4.eliminarNegativosConPositivo();
		l4.imprimirAlDerecho();
		l4.imprimirAlReves();	
	}
}