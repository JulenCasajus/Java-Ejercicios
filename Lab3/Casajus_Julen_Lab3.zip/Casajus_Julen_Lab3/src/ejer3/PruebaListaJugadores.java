package ejer3;

public class PruebaListaJugadores {

	public PruebaListaJugadores() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		//Modificar para efectuar las pruebas que considereis oportunas
		ListaDeJugadores p = new ListaDeJugadores();
		p.anadirJugador(new Jugador("Elena"));
		p.anadirJugador(new Jugador("Jon"));
		p.anadirJugador(new Jugador("Eva"));
		p.anadirJugador(new Jugador("Asier"));
		p.jugar();
	}
}