package ejer3;

import java.util.Random;
import java.util.Scanner;

public class ListaDeJugadores {
	Nodo<Jugador> first;
	Random rnd;

	public ListaDeJugadores() {	
	    rnd = new Random(System.currentTimeMillis());
	}

	//Simula el desarrollo de la partida siguiendo la descripcion del enunciado
	public void jugar() {
		if (first != null) {
			Scanner sc = new Scanner(System.in);
			Nodo<Jugador> actual = first;
			while (first != first.next) {//Mientras haya mas de un jugador
				print();
				System.out.println("PULSA RETURN PARA TIRAR EL DADO:");
				sc.nextLine();
				int puntosRestar = lanzarDado();//Numero de puntos que hay que restar al jugador actual
				System.out.println(actual.info.getNombre() + " tira el dado: " + puntosRestar);
				actual.info.setPuntos(actual.info.getPuntos() - puntosRestar);
				if(actual.info.getPuntos() < 1) {
					actual.prev.next = actual.next;
					actual.next.prev = actual.prev;
					if(actual == first) {
						first = first.next;
					}
					System.out.println(actual.info.getNombre() + " ha sido eliminado.");
				}
				actual = actual.next;
			}
			print();
			System.out.println(first.info.getNombre() + " ha ganado la partida.");
		}
	}
	
	//METODOS AUXILIARES PARA PRUEBAS
	
	//Lanza el dado y devuelve el numero que ha salido
	public int lanzarDado() {
		return (rnd.nextInt(6) + 1);
	}
	
	//Imprime la lista de jugadores
	public void print() {
		if (first != null) {
			System.out.print("ESTADO ACTUAL: ");
			Nodo<Jugador> actual = first;
			while (actual.next != first) {
				System.out.print(actual.info.toString() + " ");
				actual = actual.next;
			}
			System.out.println(actual.info.toString() + " ");
		}
	}
	
	//Anade al jugador j en la primera posicion de la lista
	public void anadirJugador(Jugador j) {
		//Lo pone como primero de la lista
		Nodo<Jugador> newNode = new Nodo<Jugador>(j);
		if (first == null) {
			first = newNode;
			newNode.next = newNode;
			newNode.prev = newNode;
		} else {
			newNode.next = first;
			newNode.prev = first.prev;
			first.prev = newNode;
			newNode.prev.next = newNode;
			first = newNode;
		}
	}
}