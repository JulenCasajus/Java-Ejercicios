package ejer1;

public class MyOrderedLinkedList<T extends Comparable<T>> {

	private Node<T> first;
	private Node<T> last;

	public MyOrderedLinkedList() {
	}

	//Inserts the specified element in the correct position.
	//Pre: the elements of the list are in ascending order
	public void addOrdered(T elem) {
		Node<T> Aux = first;
		
		while(Aux != null && Aux.info.compareTo(elem) < 0) {
			Aux = Aux.next;
		} 
			
		if(first == null) {
			Aux = new Node<T>(elem);
			first = Aux;
			last = Aux;
		} else if(Aux == first) {
			Aux = new Node<T>(elem);
			first.prev = Aux;
			Aux.next = first;
			first = Aux;
		} else if(Aux == null) {
			Aux = new Node<T>(elem);
			last.next = Aux;
			Aux.prev = last;
			last = Aux;
		} else {
			Node<T> Aux2 = new Node<T>(elem);
			Aux2.next = Aux;
			Aux2.prev = Aux.prev;
			Aux.prev.next = Aux2;
			Aux.prev = Aux2;
		}
	}
	
	//METODOS AUXILIARES PARA PRUEBAS
	
	//Returns a string representation of this collection. The string representation
    // consists of a list of the collection's elements, enclosed in square 
    // brackets ("[]"). Adjacent elements are separated by the characters ", " 
    // (comma and space). 
	@Override
	public String toString() {
	    Node<T> actual = first;
	    String resultado = "[";
	    while(actual != null) {
	    	resultado += actual.info.toString();
	    	if(actual != last) resultado += ", ";
	    	actual = actual.next;
	    }
	    resultado += "]";
		return resultado;
	}
	
	//Imprime la lista pero al reves.
	public String toStringPeroAlReves() {
	    Node<T> actual = last;
	    String resultado = "[";
	    while(actual != null) {
	    	resultado += actual.info.toString();
	    	if(actual != first) resultado += ", ";
	    	actual = actual.prev;
	    }
	    resultado += "]";
		return resultado;
	}
}