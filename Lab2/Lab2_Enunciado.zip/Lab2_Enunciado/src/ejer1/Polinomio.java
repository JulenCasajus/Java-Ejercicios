package ejer1;


public class Polinomio {

	Nodo<Termino> first;
	Nodo<Termino> last;

	
	// Devuelve en un nuevo polinomio el resultado de simplificar el polinomio
	// original sumando los terminos comunes. No modifica el polinomio original
	// En el caso del polinomio de ejemplo, devolvera el polinomio 5x^5 + 2x^3+ 6x + 9
	public Polinomio simplificarPolinomio() {
			
		Polinomio resultado = new Polinomio();
		//TO DO

		return resultado;
	}


	// Elimina el termino t del polinomio, si es que existe
	public void eliminarTermino(Termino t) {
		// TO DO
		
	}
	


	/*
	 * METODOS AUXILIARES PARA PRUEBAS
	 */

	public void imprimir() {
		Nodo<Termino> actual = first;
		if (actual != null) {
			while (actual.next != null) {
				System.out.print(actual.info.getCoeficiente() + "x^" + actual.info.getExponente());
				if (actual.next.info.getCoeficiente() >= 0)
					System.out.print("+");
				actual = actual.next;
			}
			System.out.println(actual.info.getCoeficiente() + "x^" + actual.info.getExponente());
		}

	}
	
	
	

	
}
