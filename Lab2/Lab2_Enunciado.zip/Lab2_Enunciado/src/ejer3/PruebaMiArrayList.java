package ejer3;

public class PruebaMiArrayList {

	public PruebaMiArrayList() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		//ArrayList de enteros
		MiArrayList<Integer> lista = new MiArrayList<Integer>();
		
		System.out.println("Size: "+lista.size());
		System.out.println(lista);
		
		lista.add(3);
		System.out.println(lista);
		
		//COMPLETAR CON PRUEBAS ADICIONALES
		
		

	}

}
