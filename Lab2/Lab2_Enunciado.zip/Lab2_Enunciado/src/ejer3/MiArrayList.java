package ejer3;

public class MiArrayList<T> {
	// atributos
	private T[] elementos;
	private static final int CAPACIDAD_INICIAL = 10;
	private int tamanio; //n� de elementos v�lidos que contiene el arraylist

	//Constructs an empty list with an initial capacity of ten. 
       public MiArrayList() {
   		elementos = (T[]) (new Object[CAPACIDAD_INICIAL]);
   		tamanio = 0;
       }
       
   	/*
   	 * METODOS YA IMPLEMENTADOS EN CLASE
   	 */
	
	
       //Returns the number of elements in this list. 
	public int size(){
		 return tamanio; 
	}
	
	//Returns the element at the specified position in this list. 
	public T get(int index) throws IndexOutOfBoundsException {
		if (index < 0  || index >= tamanio) {  throw new IndexOutOfBoundsException();}
		return elementos[index] ;
	}
	
    //Appends the specified element to the end of this list. Returns true.
	public boolean add(T elem) {
		if (tamanio == elementos.length) {  //Aumentar capacidad en un 50%
			int nuevaCapacidad = (int)(elementos.length*1.5);
			T[] nuevoArray = (T[])(new Object[nuevaCapacidad]);
			for(int i=0; i<tamanio; i++) {
				nuevoArray[i]=elementos[i];
			}
			elementos = nuevoArray;
		}
		elementos[tamanio] = elem;
		tamanio++;
		return true;
	}
	
	/*
	 * METODOS A IMPLEMENTAR EN LABORATORIO 2
	 */
	
	//Returns the index of the first occurrence of the specified element in this
      // list, or -1 if this list does not contain the element. 
	public int indexOf(T elem) {
		//TO DO
		return -1; //CORREGIR SI ES NECESARIO
	}
	


	//Removes the element at the specified position in this list. 
      //Returns the removed element.
       public T remove(int index) throws IndexOutOfBoundsException{
   		//TO DO
   		return null; //CORREGIR SI ES NECESARIO
       }

   	/*
   	 * METODOS AUXILIARES
   	 */
	
	//Returns a string representation of this collection. The string representation
      // consists of a list of the collection's elements in order, enclosed in square 
      // brackets ("[]"). Adjacent elements are separated by the characters ", " 
      // (comma and space). 
      @Override
	public String toString() {
    	String res = "[";
   		for(int i=0; i<tamanio-1; i++) {
  			res = res +elementos[i].toString()+", ";
  		}
  		if(tamanio>0) res = res + elementos[tamanio-1];
  		res = res + "]";
  		return res;
      }

}