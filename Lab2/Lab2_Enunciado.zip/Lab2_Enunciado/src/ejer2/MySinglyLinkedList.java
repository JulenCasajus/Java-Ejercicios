package ejer2;

import java.util.NoSuchElementException;



public class MySinglyLinkedList<T extends Comparable<T>> {

	private LinearNode<T> first;
	private LinearNode<T> last;

	private class LinearNode<T> {
		T info;
		LinearNode<T> next;

		public LinearNode(T info) {
			this.info = info;
		}
	}
	
	public MySinglyLinkedList() {
	}

	/*
	 * M�TODOS YA IMPLEMENTADOS EN CLASE
	 */

	//Returns true if this list contains no elements, false otherwise.
	public boolean isEmpty() {
		return (first == null);
	}

	//Appends the specified element to the front of this list.
	public void addFirst(T elem) {
		LinearNode<T> newNode = new LinearNode<T>(elem);
		newNode.next = first;
		first = newNode;
		last = newNode;
	}

	//Returns true if this list contains the specified element, false otherwise.
	public boolean contains(Object o) {
		T elem = (T)o;
		LinearNode<T> actual = first;
		while (actual != null) {
			if (elem.equals(actual.info))
				return true;
			actual = actual.next;
		}
		return false;
	}

	/*
	 * M�TODOS A IMPLEMENTAR EN EL LABORATORIO 2
	 */
	
	//Removes the element at the first position in this list. 
    //Returns the removed element, or an exception if the list is empty
	public T removeFirst() throws NoSuchElementException {
		//TO DO
		return null;//CORREGIR SI ES NECESARIO
	}
	
	
	//Inserts the specified element in the correct position.
	//Pre: the elements of the list are in ascending order
	public void addOrdered(T elem) {
		//TO DO
	
	}
	


	/*
	 * OTROS METODOS (AUXILIARES Y/O DE IMPLEMENTACION OPCIONAL)
	 */
	
	//Returns a string representation of this collection. The string representation
    // consists of a list of the collection's elements in order, enclosed in square 
    // brackets ("[]"). Adjacent elements are separated by the characters ", " 
    // (comma and space). 
	@Override
	public String toString() {
		LinearNode<T> actual = first;
		String res = "";
		while(actual!=null) {
			res = res+actual.info.toString()+" ";
			actual = actual.next;
		}
	    return res;
	}
	
    /*
    //Returns the number of elements in this list. 	
	public int size(){}
	
	//Returns the index of the first occurrence of the specified element in this
    // list, or -1 if this list does not contain the element.
	public int indexOf(Object o) {}
	
    //Removes the first occurrence of the specified element from this list, if it is 
    //present. Returns true if it has been removed, false otherwise.
	public boolean remove(Object o){}
	
    //Appends the specified element to the end of this list.
	public void addLast(T elem){}
	
	//Removes the element at the last position in this list. 
    //Returns the removed element, or throws an exception if list is empty
	public T removeLast() throws NoSuchElementException {}
	
	//Returns the first element in the list, or throws an exception if list is empty
	public T getFirst() throws NoSuchElementException {}
	
	//Returns the last element in the list, or throws an exception if list is empty
	public T getLast() throws NoSuchElementException {}
	
    //Replaces the element at the specified position in this list with the specified element. 
    // Returns the replaced element	
	public T set(int index, T elem) throws IndexOutOfBoundsException{}	
	
	
	*/


}
