package ejer2;

import java.util.NoSuchElementException;

public class PruebaMySinglyLinkedList {

	public PruebaMySinglyLinkedList() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		//Lista de enteros
		MySinglyLinkedList<Integer> lista = new MySinglyLinkedList<Integer>();
		
		System.out.println("Is empty?: "+lista.isEmpty());
		
		lista.addOrdered(3);
		System.out.println("Tras insertar el 3: "+lista);
		lista.addOrdered(1);
		System.out.println("Tras insertar el 1: "+lista);
		lista.addOrdered(7);
		System.out.println("Tras insertar el 7: "+lista);
		
		try {	
			for(int i=0; i<4;i++) {
				int eliminado = lista.removeFirst();
				System.out.println("Tras eliminar el primer elemento: "+lista);
				System.out.println("El elemento devuelto era "+eliminado);				
			}

		}catch(NoSuchElementException ex) {
			System.out.println("No hay más elementos");
		}
		
		

		
		
		//COMPLETAR CON PRUEBAS ADICIONALES

	}

}
