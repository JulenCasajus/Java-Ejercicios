package ejer1;

public class Polinomio {

	Nodo<Termino> first;
	Nodo<Termino> last;
	
	//Devuelve en un nuevo polinomio el resultado de simplificar el polinomio original sumando los terminos comunes. No modifica el polinomio original
	//En el caso del polinomio de ejemplo, devolvera el polinomio 5x^5 + 2x^3+ 6x + 9
	public Polinomio simplificarPolinomio() {
			
		Polinomio resultado = new Polinomio();
		
		Nodo<Termino> actual = first;
		
		if (actual != null) {
			int coeficiente = actual.info.getCoeficiente();
			while (actual.next != null) {
				if(actual.info.getExponente() == actual.next.info.getExponente()) {
					coeficiente += actual.next.info.getCoeficiente();
				} else {
					Nodo<Termino> newNodo = new Nodo<>(new Termino(coeficiente, actual.info.getExponente()));
					if (resultado.first == null) {
						resultado.first = newNodo;
						resultado.last = newNodo;
				    } else {
				    	resultado.last.next = newNodo;
				        resultado.last = newNodo;
				    }
					coeficiente = actual.next.info.getCoeficiente();
				}
				actual = actual.next;
			}
			
			Nodo<Termino> newNodo = new Nodo<>(new Termino(coeficiente, actual.info.getExponente()));
			 
			if (resultado.first == null) {
				resultado.first = newNodo;
				resultado.last = newNodo;
		    } else {
		    	resultado.last.next = newNodo;
		        resultado.last = newNodo;
		    }
		}
		return resultado;
	}

	// Elimina el termino t del polinomio, si es que existe
	public void eliminarTermino(Termino t) {
		Nodo<Termino> actual = first;
		if(actual != null) {
			if(actual.info.equals(t)) {
				first = first.next;
			}
			while(actual.next != null) {
				if(actual.next.info.equals(t)) {
					actual.next = actual.next.next;
				}
				actual = actual.next;
			}
		}
	}
	


	/*
	 * METODOS AUXILIARES PARA PRUEBAS
	 */

	public void imprimir() {
		Nodo<Termino> actual = first;
		if (actual != null) {
			while (actual.next != null) {
				System.out.print(actual.info.getCoeficiente() + "x^" + actual.info.getExponente());
				if (actual.next.info.getCoeficiente() >= 0)
					System.out.print("+");
				actual = actual.next;
			}
			System.out.println(actual.info.getCoeficiente() + "x^" + actual.info.getExponente());
		}
	}	
}