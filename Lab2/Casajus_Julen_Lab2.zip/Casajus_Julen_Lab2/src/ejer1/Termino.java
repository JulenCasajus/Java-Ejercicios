package ejer1;

public class Termino implements Comparable<Termino>{
	private int coeficiente;
	private int exponente;

	public Termino(int coeficiente, int exponente) {
		this.setCoeficiente(coeficiente);
		this.setExponente(exponente);
	}

	public int getExponente() {
		return exponente;
	}

	public void setExponente(int exponente) {
		this.exponente = exponente;
	}

	public int getCoeficiente() {
		return coeficiente;
	}

	public void setCoeficiente(int coeficiente) {
		this.coeficiente = coeficiente;
	}
	
	@Override
	public boolean equals(Object o) {
		Termino t = (Termino)o;
		return (this.coeficiente==t.coeficiente && this.exponente==t.exponente);
	}

	@Override
	public int compareTo(Termino o) {
		Termino t = (Termino) o;
		if(this.exponente<t.exponente) return -1;
		else if(this.exponente>t.exponente) return 1;
		else {//this.exponente==t.exponente
			if(this.coeficiente<t.coeficiente) return -1;
			else if(this.coeficiente>t.coeficiente) return 1;
			else return 0;
		}		
	}
}