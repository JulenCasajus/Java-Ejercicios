package ejer1;

public class PruebaPolinomio {

	public static void main(String[] args) {
		Polinomio p1 = new Polinomio();
		Termino t11 = new Termino(3,5);
		Termino t12 = new Termino(2,5);
		Termino t13 = new Termino(2,3);
		Termino t14 = new Termino(8,1);
		Termino t15 = new Termino(-2,1);
		Termino t16 = new Termino(9,0);
		
		Nodo<Termino> n11 = new Nodo<Termino>(t11);
		Nodo<Termino> n12 = new Nodo<Termino>(t12);
		Nodo<Termino> n13 = new Nodo<Termino>(t13);
		Nodo<Termino> n14 = new Nodo<Termino>(t14);
		Nodo<Termino> n15 = new Nodo<Termino>(t15);
		Nodo<Termino> n16 = new Nodo<Termino>(t16);
		
		p1.first = n11;
		p1.last = n16;
		
		n11.next = n12;
		n12.next = n13;
		n13.next = n14;
		n14.next = n15;
		n15.next = n16;
		
		System.out.print("\nPolinomio original :");
		p1.imprimir();
		
		System.out.print("\nPolinomio simplificado :");
		Polinomio simp_p1 = p1.simplificarPolinomio();
	    simp_p1.imprimir();
	    
		System.out.print("\nTras quitar 8x^1 al polinomio original :");
	    p1.eliminarTermino(new Termino(8,1));
	    p1.imprimir();
	}
}