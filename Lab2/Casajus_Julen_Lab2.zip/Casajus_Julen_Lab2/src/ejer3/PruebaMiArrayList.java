package ejer3;

public class PruebaMiArrayList {

	public PruebaMiArrayList() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		//ArrayList de enteros
		MiArrayList<Integer> lista = new MiArrayList<Integer>();
		
		System.out.println("Size: " + lista.size());
		System.out.println(lista + "\n");
		
		lista.add(3);
		System.out.println("Añadimos el 3 a la lista:" + lista);
		lista.add(6);
		System.out.println("Añadimos el 6 a la lista:" + lista);
		lista.add(9);
		System.out.println("Añadimos el 9 a la lista:" + lista);
		lista.add(1);
		System.out.println("Añadimos el 1 a la lista:" + lista + "\n");		
		
		System.out.println("Posicion del 3 en la lista:" + lista.indexOf(3));
		System.out.println("Posicion del 9 en la lista:" + lista.indexOf(9));
		System.out.println("Posicion del 11 en la lista:" + lista.indexOf(11) + "\n");
		
		try {	
			for(int i = 0; i < 4; i++) {
				int removed = lista.remove(1);
				System.out.println("Tras eliminar el elemento en la posicion 1: " + lista);
				System.out.println("El elemento eliminado era " + removed + "\n");				
			}

		}catch(IndexOutOfBoundsException ex) {
			System.out.println("El indice dado esta fuera de los limites de la lista");
		}
	}
}