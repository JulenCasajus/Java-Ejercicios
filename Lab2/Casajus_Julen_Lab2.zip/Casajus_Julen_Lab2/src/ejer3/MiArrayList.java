package ejer3;

public class MiArrayList<T> {

	private T[] elementos;
	private static final int CAPACIDAD_INICIAL = 10;
	private int tamano; //numero de elementos validos que contiene el arraylist

	//Constructs an empty list with an initial capacity of ten. 
	public MiArrayList() {
		elementos = (T[]) (new Object[CAPACIDAD_INICIAL]);
		tamano = 0;
    }
       
   	/*
   	 * METODOS YA IMPLEMENTADOS EN CLASE
   	 */
	
    //Returns the number of elements in this list. 
	public int size() {
		 return tamano; 
	}
	
	//Returns the element at the specified position in this list. 
	public T get(int index) throws IndexOutOfBoundsException {
		if (index < 0  || index >= tamano) throw new IndexOutOfBoundsException();
		return elementos[index];
	}
	
    //Appends the specified element to the end of this list. Returns true.
	public boolean add(T elem) {
		if (tamano == elementos.length) {//Aumentar capacidad en un 50%
			int nuevaCapacidad = (int)(elementos.length * 1.5);
			T[] nuevoArray = (T[])(new Object[nuevaCapacidad]);
			for(int i = 0; i < tamano; i++) {
				nuevoArray[i] = elementos[i];
			}
			elementos = nuevoArray;
		}
		elementos[tamano] = elem;
		tamano++;
		return true;
	}
	
	/*
	 * METODOS A IMPLEMENTAR EN LABORATORIO 2
	 */
	
	//Returns the index of the first occurrence of the specified element in this list, or -1 if this list does not contain the element. 
	public int indexOf(T elem) {
		for(int i = 0; i < tamano - 1; i++) {
			if(elementos[i].equals(elem)) return i;
		}
		return -1;
	} 
	
	//Removes the element at the specified position in this list. 
    //Returns the removed element.
    public T remove(int index) throws IndexOutOfBoundsException{
    	if (index < 0  || index >= tamano) throw new IndexOutOfBoundsException();
    	T removed = elementos[index];
    	for(int i = index; i < tamano - 1; i++) {
        	elementos[i] = elementos[i+1];
    	}
    	tamano--;
    	return removed;
    }

   	/*
   	 * METODOS AUXILIARES
   	 */
	
	//Returns a string representation of this collection. The string representation
      // consists of a list of the collection's elements in order, enclosed in square 
      // brackets ("[]"). Adjacent elements are separated by the characters ", " 
      // (comma and space). 
      @Override
	public String toString() {
    	String res = "[";
   		for(int i = 0; i < tamano-1; i++) {
  			res = res + elementos[i].toString() + ", ";
  		}
  		if(tamano > 0) res = res + elementos[tamano - 1];
  		res = res + "]";
  		return res;
      }
}