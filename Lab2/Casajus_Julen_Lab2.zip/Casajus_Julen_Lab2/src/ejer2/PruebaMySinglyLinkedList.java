package ejer2;

import java.util.NoSuchElementException;

public class PruebaMySinglyLinkedList {

	public PruebaMySinglyLinkedList() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		//Lista de enteros
		MySinglyLinkedList<Integer> lista = new MySinglyLinkedList<Integer>();
		
		System.out.println("Is empty?: " + lista.isEmpty());
		
		lista.addOrdered(3);
		System.out.println("Tras insertar el 3 ordenado: " + lista);
		lista.addOrdered(1);
		System.out.println("Tras insertar el 1 ordenado: " + lista);
		lista.addOrdered(7);
		System.out.println("Tras insertar el 7 ordenado: " + lista);
		
		try {	
			for(int i = 0; i < 4; i++) {
				int eliminado = lista.removeFirst();
				System.out.println("Tras eliminar el primer elemento: " + lista);
				System.out.println("El elemento eliminado era " + eliminado);				
			}

		}catch(NoSuchElementException ex) {
			System.out.println("No hay mas elementos");
		}
		
		lista.addFirst(4);
		System.out.println("Tras insertar el 4 al principio: " + lista);
		lista.addFirst(2);
		System.out.println("Tras insertar el 2 al principio: " + lista);
		lista.addOrdered(3);
		System.out.println("Tras insertar el 3 ordenado: " + lista);
		
		
		System.out.println("Contiene el 7?: " + lista.contains(7));
		System.out.println("Contiene el 2?: " + lista.contains(2));
	}
}