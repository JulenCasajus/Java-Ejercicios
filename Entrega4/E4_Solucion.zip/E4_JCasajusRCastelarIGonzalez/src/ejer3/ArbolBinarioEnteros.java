package ejer3;

import java.util.LinkedList;

public class ArbolBinarioEnteros {
	
	NodoEnteros root;

	//Metodos basicos
	
	public ArbolBinarioEnteros() {
		this.root = null;
	}
	
	public ArbolBinarioEnteros(Integer info) {
		this.root = new NodoEnteros(info);
	}

	public ArbolBinarioEnteros(NodoEnteros root) {
		this.root = root;
	}

	public boolean isEmpty() {
		return (root == null);
	}
	
	public void inundar() {
		if(!isEmpty()) root.inundar();
	}
	
	//Metodos auxiliares para pruebas
	
	//Devuelve una lista con los elementos del arbol (en inorden)
	 public LinkedList<Integer> elementosEnInOrden(){
		 if(isEmpty()) return new LinkedList<Integer>();
		 else return root.elementosEnInOrden();
	 }
	 
	public void imprimirArbol() {
		if (isEmpty())
			System.out.println("*");
		else {
			root.imprimirArbol();
			System.out.println();
		}
	}
}
