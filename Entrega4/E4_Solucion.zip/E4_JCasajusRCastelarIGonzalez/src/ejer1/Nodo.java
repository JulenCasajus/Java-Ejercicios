package ejer1;


public class Nodo<T extends Comparable<T>> {

	T info;
	Nodo<T> left;
	Nodo<T> right;

	// Metodos basicos

	public Nodo(T info) {
		this.info = info;
	}

	// Devuelve si el nodo es hoja
	public boolean isLeaf() {
		return (left == null && right == null);
	}

	// Devuelve si el nodo tiene subarbol izquierdo
	public boolean hasLeft() {
		return (left != null);
	}

	// Devuelve si el nodo tiene subarbol derecho
	public boolean hasRight() {
		return (right != null);
	}

	public boolean esLleno() {
		if(hasLeft() && hasRight()) return left.esLleno() && right.esLleno();
		if(isLeaf()) return true;
		return false;
	}
}