package ejer2;

import java.util.LinkedList;

public class Nodo<T extends Comparable<T>> {

	T info;
	Nodo<T> left;
	Nodo<T> right;

	// Metodos basicos

	public Nodo(T info) {
		this.info = info;
	}

	// Devuelve si el nodo es hoja
	public boolean isLeaf() {
		return (left == null && right == null);
	}

	// Devuelve si el nodo tiene subarbol izquierdo
	public boolean hasLeft() {
		return (left != null);
	}

	// Devuelve si el nodo tiene subarbol derecho
	public boolean hasRight() {
		return (right != null);
	}

	public LinkedList<T> listaDeMenores(T elem) {
		LinkedList<T> Lista = new LinkedList<T>();
		if(hasLeft()) Lista.addAll(left.listaDeMenores(elem));
		if(info.compareTo(elem) == -1) Lista.add(info);
		if(hasRight()) Lista.addAll(right.listaDeMenores(elem));
		return Lista;
	}

	//Metodos auxiliares para pruebas
	
	public void imprimirArbol() {
		if(this.isLeaf()) System.out.print("[ " + info + " ] ");
		else {
			System.out.print("[ " + info + " ");
			if(hasLeft()) left.imprimirArbol();
			else System.out.print("* ");
			if(hasRight()) right.imprimirArbol();
			else System.out.print("* ");
			System.out.print("] ");
		}
	}
}