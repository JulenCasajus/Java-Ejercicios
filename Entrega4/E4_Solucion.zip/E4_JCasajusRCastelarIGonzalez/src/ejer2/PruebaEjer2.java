package ejer2;

import java.io.File;
import java.util.LinkedList;
import java.util.Scanner;

public class PruebaEjer2 {
	
	
	public static void main(String[] args) throws Exception {
		
		ArbolBinario<Integer> ab;
		
		for(int i = 0; i <= 7; i++) {
			
			System.out.println("\n ---------\n  ARBOL "+i+"\n ---------");
			ab = cargar("src/files/arbol"+i+".txt");
			
			 System.out.print("Arbol: ");
			 ab.imprimirArbol();
			 
             LinkedList<Integer> lista1 = ab.listaDeMenores(6);             
             System.out.println("Menores que 6: " + lista1);
             
             LinkedList<Integer> lista2 = ab.listaDeMenores(0);
             System.out.println("Menores que 0: " + lista2);
             
             LinkedList<Integer> lista3 = ab.listaDeMenores(40);
             System.out.println("Menores que 40: " + lista3);        
		}
	}		
	
	//CODIGO PARA LA CARGA DE LOS EJEMPLOS DE PRUEBA, NO MODIFICAR
	
	public static ArbolBinario<Integer> cargar(String nomFich) throws Exception {
		ArbolBinario<Integer> result = new ArbolBinario<Integer>();
		Scanner source = new Scanner(new File(nomFich));
		String token = source.next();
		if (token.equals("*"))
			result.root = null;
		else if (token.equals("["))
			result.root = cargar(source);
		else
			throw new Exception(String.format("Unexpected token when reading " + "binary tree: %s", token));
		return result;
	}

	public static Nodo<Integer> cargar(Scanner source) throws Exception{
		Nodo<Integer> result = new Nodo<Integer>(source.nextInt());
		String token = source.next();
		if (token.equals("]")) {
			result.left = null;
			result.right = null;
		} else {
			if (token.equals("["))
				result.left = cargar(source);
			else if (token.equals("*"))
				result.left = null;
			else
				throw new Exception(String.format("Unexpected token when " + "reading binary tree: %s", token));
			token = source.next();
			if (token.equals("["))
				result.right = cargar(source);
			else if (token.equals("*"))
				result.right = null;
			else
				throw new Exception(String.format("Unexpected token when " + "reading binary tree: %s", token));
			token = source.next();
			if (!token.equals("]"))
				throw new Exception(String.format("Unexpected token when " + "reading binary tree: %s", token));
		}
		return result;
	}
	//FIN DEL CODIGO PARA LA CARGA DE LOS EJEMPLOS DE PRUEBA
}
