package ejer1;

import java.util.LinkedList;

public class ArbolBinarioEnteros {
	
	NodoEnteros root;

	//Metodos basicos
	
	public ArbolBinarioEnteros() {
		root = null;
	}
	
	public ArbolBinarioEnteros(Integer info) {
		root = new NodoEnteros(info);
	}


	public ArbolBinarioEnteros(NodoEnteros root) {
		this.root = root;
	}

	public boolean isEmpty() {
		return (root == null);
	}
	
	public boolean esEquiponderado() {
		if(isEmpty()) return true;
		return root.esEquiponderado().isEqui();
	}	

	//METODOS AUXILIARES PARA PRUEBAS
	
	//Devuelve una lista con los elementos del arbol (en inorden)
	public LinkedList<Integer> elementosEnInOrden(){
		if(isEmpty()) return new LinkedList<Integer>();
		else return root.elementosEnInOrden();
	}

	public void imprimirArbol() {
			if (isEmpty())
			System.out.println("*");
		else {
			root.imprimirArbol();
			System.out.println();
		}
	}	
}