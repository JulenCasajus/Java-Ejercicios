package ejer1;

import java.util.LinkedList;

public class NodoEnteros {

	Integer info;
	NodoEnteros left;
	NodoEnteros right;

	// Metodos basicos
	
	public NodoEnteros(Integer info) {
		this.info = info;
	}

	// Devuelve si el nodo es hoja
	public boolean isLeaf() {
		return (left == null && right == null);
	}

	// Devuelve si el nodo tiene subarbol izquierdo
	public boolean hasLeft() {
		return (left != null);
	}

	// Devuelve si el nodo tiene subarbol derecho
	public boolean hasRight() {
		return (right != null);
	}

	public SumaNodos esEquiponderado() {
        SumaNodos sumL, sumR;
        if(isLeaf()) return new SumaNodos(info, true);
        if(!hasLeft() || !hasRight()) return new SumaNodos(info, false);
        sumL = left.esEquiponderado();
        sumR = right.esEquiponderado();
        if (sumL.isEqui() && sumR.isEqui() && sumL.sum == sumR.sum) return new SumaNodos(info + sumL.sum + sumR.sum, true);
        return new SumaNodos(info + sumL.sum + sumR.sum, false);
    }
	
	//METODOS AUXILIARES PARA PRUEBAS
	
	public LinkedList<Integer> elementosEnInOrden() {
		LinkedList<Integer> resultado = new LinkedList<Integer>();
		if (hasLeft()) resultado.addAll(left.elementosEnInOrden());
		resultado.addLast(info);
		if (hasRight()) resultado.addAll(right.elementosEnInOrden());
		return resultado;
	}
	
	public void imprimirArbol() {
		if(isLeaf()) System.out.print("[ " + info + " ] ");
		else {
			System.out.print("[ " + info + " ");
			if(hasLeft()) left.imprimirArbol();
			else System.out.print("* ");
			if(hasRight()) right.imprimirArbol();
			else System.out.print("* ");
			System.out.print("] ");
		}		
	}
}