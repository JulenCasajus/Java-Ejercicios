package ejer1;

public class SumaNodos {

	int sum;
	boolean equi;

	public SumaNodos(int sum, boolean equi) {
		this.sum = sum;
		this.equi = equi;
	}

	public int getSum() {
		return sum;
	}

	public void setSum(int sum) {
		this.sum = sum;
	}

	public boolean isEqui() {
		return equi;
	}

	public void setEqui(boolean equi) {
		this.equi = equi;
	}
}