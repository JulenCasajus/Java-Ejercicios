package ejer2;

import java.util.LinkedList;

public class NodoABBEnteros {

	Integer info;
	NodoABBEnteros left;
	NodoABBEnteros right;

	// Metodos basicos

	public NodoABBEnteros(Integer info) {
		this.info = info;
	}

	// Devuelve si el nodo es hoja
	public boolean isLeaf() {
		return (left == null && right == null);
	}

	// Devuelve si el nodo tiene subarbol izquierdo
	public boolean hasLeft() {
		return (left != null);
	}

	// Devuelve si el nodo tiene subarbol derecho
	public boolean hasRight() {
		return (right != null);
	}
	
	public LinkedList<Integer> listaNivelDeMayores(Integer num, int niv) {
		LinkedList<Integer> lista = new LinkedList<Integer>();
		if(niv > 0 && info > num && hasLeft()) lista.addAll(left.listaNivelDeMayores(num, niv - 1));
		if(niv == 0 && info > num) lista.add(info);
		if(niv > 0 && hasRight()) lista.addAll(right.listaNivelDeMayores(num, niv - 1));
		return lista;
	}
	
	//METODOS AUXILIARES PARA PRUEBAS
	
	public LinkedList<Integer> elementosEnInOrden() {
		LinkedList<Integer> resultado = new LinkedList<Integer>();
		if (hasLeft()) resultado.addAll(left.elementosEnInOrden());
		resultado.addLast(info);
		if (hasRight()) resultado.addAll(right.elementosEnInOrden());
		return resultado;
	}
	
	public void imprimirArbol() {
		if(this.isLeaf()) System.out.print("[ " + info + " ] ");
		else {
			System.out.print("[ " + info + " ");
			if(hasLeft()) left.imprimirArbol();
			else System.out.print("* ");
			if(hasRight()) right.imprimirArbol();
			else System.out.print("* ");
			System.out.print("] ");
		}		
	}
}