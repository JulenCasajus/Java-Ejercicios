package ejer3;

public class SumaSecuencias {

	int sum;
	int izq;
	int der;
	
	public SumaSecuencias(int sum, int izq, int der) {
		this.sum = sum;
		this.izq = izq;		
		this.der = der;
	}
	
	public SumaSecuencias(int sum, int izq) {
		this.sum = sum;
		this.izq = izq;		
	}

	public int getSum() {
		return sum;
	}

	public void setSum(int sum) {
		this.sum = sum;
	}

	public int getIzq() {
		return izq;
	}

	public void setIzq(int izq) {
		this.izq = izq;
	}
	
	public int getDer() {
		return der;
	}

	public void setDer(int der) {
		this.der = der;
	}
}