package ejer3;

import java.util.LinkedList;

public class NodoEnteros {

	Integer info;
	NodoEnteros left;
	NodoEnteros right;

	// Metodos basicos

	public NodoEnteros(Integer info) {
		this.info = info;
	}

	// Devuelve si el nodo es hoja
	public boolean isLeaf() {
		return (left == null && right == null);
	}

	// Devuelve si el nodo tiene subarbol izquierdo
	public boolean hasLeft() {
		return (left != null);
	}

	// Devuelve si el nodo tiene subarbol derecho
	public boolean hasRight() {
		return (right != null);
	}
	
	public SumaSecuencias numSecuencias() {
		if(!isLeaf()) {
			SumaSecuencias SSL = left.numSecuencias();
			SumaSecuencias SSR = right.numSecuencias();
			if(SSL.der == 1 && SSR.izq == 1) 
				return new SumaSecuencias(SSL.sum + SSR.sum - 1, SSL.izq, SSR.der);
			return new SumaSecuencias(SSL.sum + SSR.sum, SSL.izq, SSR.der);
		} if(info == 1) return new SumaSecuencias(1, 1, 1);
		return new SumaSecuencias(0, 0, 0);
	}
	
	// OTRA MANERA, PASANDO POR VALOR SI LA HOJA A LA IZQUIERDA ES UN 1
	 public SumaSecuencias numSecuencias(int izq) {
		SumaSecuencias SSL = new SumaSecuencias(0, 1), SSR = new SumaSecuencias(0, 1);
		if(isLeaf() && info == 1) {
			if(izq == 1)return new SumaSecuencias(0, 1);
			return new SumaSecuencias(1, 1);
		} if(!isLeaf()) {
			SSL = left.numSecuencias(izq);
			SSR = right.numSecuencias(SSL.izq);
		} return new SumaSecuencias(SSL.getSum() + SSR.getSum(), SSR.izq);
	}
	
	//METODOS AUXILIARES PARA PRUEBAS
	
	public LinkedList<Integer> elementosEnInOrden() {
		LinkedList<Integer> resultado = new LinkedList<Integer>();
		if (hasLeft()) resultado.addAll(left.elementosEnInOrden());
		resultado.addLast(info);
		if (hasRight()) resultado.addAll(right.elementosEnInOrden());
		return resultado;
	}
	
	public void imprimirArbol() {
		if(isLeaf()) System.out.print("[ " + info + " ] ");
		else {
			System.out.print("[ " + info + " ");
			if(hasLeft()) left.imprimirArbol();
			else System.out.print("* ");
			if(hasRight()) right.imprimirArbol();
			else System.out.print("* ");
			System.out.print("] ");
		}		
	}
}