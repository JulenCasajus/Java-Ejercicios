package ejer1;

import java.util.LinkedList;

public class ArbolBinarioEnteros {
	
	NodoEnteros root;

	//M�todos b�sicos
	
	public ArbolBinarioEnteros() {
		this.root = null;
	}
	
	public ArbolBinarioEnteros(Integer info) {
		this.root = new NodoEnteros(info);
	}


	public ArbolBinarioEnteros(NodoEnteros root) {
		this.root = root;
	}

	public boolean isEmpty() {
		return (root == null);
	}
	

	// EJERCICIO 1
	public boolean esEquiponderado() {
		//TO DO
		return false; //CORREGIR SI NECESARIO
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//M�todos auxiliares para pruebas
	
	//Devuelve una lista con los elementos del �rbol (en inorden)
	 public LinkedList<Integer> elementosEnInOrden(){
		 if(this.isEmpty()) return new LinkedList<Integer>();
		 else return this.root.elementosEnInOrden();
	 }
	 
	 
		public void imprimirArbol() {
			if (this.isEmpty())
				System.out.println("*");
			else {
				this.root.imprimirArbol();
				System.out.println();
			}

		}

	
	

}
