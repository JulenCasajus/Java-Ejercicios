package ejer2;

import java.io.File;
import java.util.LinkedList;
import java.util.Scanner;

public class PruebaEjer2 {
	
	
	public static void main(String[] args) throws Exception {
		
				
		ABBEnteros ab;
		
		for(int i=0; i<=5; i++) {
			
			System.out.println("\n-------------\n �RBOL "+i+"\n-------------");
			ab = cargar("src/filesEjer2/arbolABB_2."+i+".txt");
			
			 System.out.print("�rbol: ");
			 ab.imprimirArbol();
			 
			 
             LinkedList<Integer> lista1 = ab.listaNivelDeMayores(6, 2);            
             System.out.println("Mayores que 6 en nivel 2: "+lista1);
             
             LinkedList<Integer> lista2 = ab.listaNivelDeMayores(18, 2);            
             System.out.println("Mayores que 18 en nivel 2: "+lista2);
             
             LinkedList<Integer> lista3 = ab.listaNivelDeMayores(5, 3);            
             System.out.println("Mayores que 5 en nivel 3: "+lista3);
             
             LinkedList<Integer> lista4 = ab.listaNivelDeMayores(10, 4);            
             System.out.println("Mayores que 10 en nivel 4: "+lista4);

             
			
		}	

	}
	
	
	
	
	
	
	
	//C�DIGO PARA LA CARGA DE LOS EJEMPLOS DE PRUEBA, NO MODIFICAR
	
	public static ABBEnteros cargar(String nomFich) throws Exception {
		ABBEnteros result = new ABBEnteros();
		Scanner source = new Scanner(new File(nomFich));
		String token = source.next();
		if (token.equals("*"))
			result.root = null;
		else if (token.equals("["))
			result.root = cargar(source);
		else
			throw new Exception(String.format("Unexpected token when reading " + "binary tree: %s", token));
		return result;
	}

	public static NodoABBEnteros cargar(Scanner source) throws Exception{
		NodoABBEnteros result = new NodoABBEnteros(source.nextInt());
		String token = source.next();
		if (token.equals("]")) {
			result.left = null;
			result.right = null;
		} else {
			if (token.equals("["))
				result.left = cargar(source);
			else if (token.equals("*"))
				result.left = null;
			else
				throw new Exception(String.format("Unexpected token when " + "reading binary tree: %s", token));
			token = source.next();
			if (token.equals("["))
				result.right = cargar(source);
			else if (token.equals("*"))
				result.right = null;
			else
				throw new Exception(String.format("Unexpected token when " + "reading binary tree: %s", token));
			token = source.next();
			if (!token.equals("]"))
				throw new Exception(String.format("Unexpected token when " + "reading binary tree: %s", token));
		}
		return result;
	}
	
	//FIN DEL C�DIGO PARA LA CARGA DE LOS EJEMPLOS DE PRUEBA

}
