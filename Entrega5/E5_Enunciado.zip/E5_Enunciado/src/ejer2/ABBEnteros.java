package ejer2;

import java.util.LinkedList;

public class ABBEnteros {
	
	NodoABBEnteros root;

	//M�todos b�sicos
	
	public ABBEnteros() {
		this.root = null;
	}
	
	public ABBEnteros(Integer info) {
		this.root = new NodoABBEnteros(info);
	}


	public ABBEnteros(NodoABBEnteros root) {
		this.root = root;
	}

	public boolean isEmpty() {
		return (root == null);
	}
	

	// EJERCICIO 2
	
	public LinkedList<Integer> listaNivelDeMayores(Integer num, int niv) {
		//TO DO
		return null; //CORREGIR SI NECESARIO
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//M�todos auxiliares para pruebas
	
	//Devuelve una lista con los elementos del �rbol (en inorden)
	 public LinkedList<Integer> elementosEnInOrden(){
		 if(this.isEmpty()) return new LinkedList<Integer>();
		 else return this.root.elementosEnInOrden();
	 }
	 
	 
		public void imprimirArbol() {
			if (this.isEmpty())
				System.out.println("*");
			else {
				this.root.imprimirArbol();
				System.out.println();
			}

		}

	
	

}
