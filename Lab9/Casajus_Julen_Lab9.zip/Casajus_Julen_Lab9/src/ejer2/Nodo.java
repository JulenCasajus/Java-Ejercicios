package ejer2;

public class Nodo<T> {
    T info;

    public Nodo(T info) {
        this.info = info;
    }    
    
    public T getInfo() {
    	return this.info;
    }
    
    @Override
    public boolean equals(Object o) {
    	if(o == this) return true;
    	if(!(o instanceof Nodo<?>)) {
    		return false;
    	}    	
    	@SuppressWarnings("unchecked")
		Nodo<T> cast = (Nodo<T>) o;
    	return cast.info.equals(this.info);
    }
    
    @Override
    public int hashCode() {
    	return this.info.hashCode();
    }
    
    @Override
    public String toString() {
    	return this.info.toString();
    }
}