package ejer3;

public class PruebaEjer3 {

	public PruebaEjer3() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		GrafoNoDirigidoListas<String> grafo = new GrafoNoDirigidoListas<String>();
		
		Nodo<String> a = new Nodo<String>("A");
		Nodo<String> b = new Nodo<String>("B");
		Nodo<String> c = new Nodo<String>("C");
		Nodo<String> d = new Nodo<String>("D");
		Nodo<String> e = new Nodo<String>("E");
		Nodo<String> f = new Nodo<String>("F");
		Nodo<String> g = new Nodo<String>("G");
		
		grafo.anadirNodo(a);
		grafo.anadirNodo(b);
		grafo.anadirNodo(c);
		grafo.anadirNodo(d);
		grafo.anadirNodo(e);
		grafo.anadirNodo(f);
		grafo.anadirNodo(g);

		a.adyacentes.add(c);
		a.adyacentes.add(d);
		b.adyacentes.add(d);
		b.adyacentes.add(e);
		c.adyacentes.add(a);
		c.adyacentes.add(e);
		c.adyacentes.add(f);		
		d.adyacentes.add(a);
		d.adyacentes.add(b);
		e.adyacentes.add(b);
		e.adyacentes.add(c);
		e.adyacentes.add(g);
		f.adyacentes.add(c);
		f.adyacentes.add(g);
		g.adyacentes.add(e);
		g.adyacentes.add(f);	

		System.out.println("Grafo: ");
		grafo.imprimirGrafo();
		System.out.println("Es conexo?: " + grafo.esConexoAnchura());
		
		Nodo<String> h = new Nodo<String>("H");
		Nodo<String> i = new Nodo<String>("I");
		grafo.anadirNodo(h);
		grafo.anadirNodo(i);
		h.adyacentes.add(i);
		i.adyacentes.add(h);
	
		System.out.println("\nTras anadir los nodos H e I: ");
		System.out.println("Grafo: ");
		grafo.imprimirGrafo();
		System.out.println("Es conexo?: " + grafo.esConexoAnchura());	
	}
}