package ejer3;

import java.util.ArrayList;

public class GrafoNoDirigidoListas<T> {
	
	int numNodos;
	ArrayList<Nodo<T>> nodos;

	public GrafoNoDirigidoListas() {
		this.numNodos = 0;
		nodos = new ArrayList<Nodo<T>>();
	}

	public void anadirNodo(Nodo<T> nodo) {
		nodos.add(nodo);
		this.numNodos++;
	}
	
	//Devuelve true si el grafo es conexo. Se pide implementar mediante recorrido en anchura
	public boolean esConexoAnchura() {
		ArrayList<Nodo<T>> grafo = new ArrayList<>();
		ArrayList<Nodo<T>> visitado = new ArrayList<>();

		Nodo<T> aux;
		
		grafo.add(nodos.get(0));
		visitado.add(nodos.get(0));

		while(!grafo.isEmpty()) {
			aux = grafo.remove(0);
			
			for(Nodo<T> adyacente : aux.adyacentes) {
				if(!visitado.contains(adyacente)) {
					grafo.add(adyacente);
					visitado.add(adyacente);
				}
			}
		}
		
		if(visitado.size() < numNodos) return false;	
		return true;
	}
	
	public void imprimirGrafo() {
		for (Nodo<T> nodo : nodos) {
			System.out.print(nodo.info.toString() + ": ");
			for (Nodo<T> ady : nodo.adyacentes) {
				System.out.print(ady.info.toString() + " ");
			}
			System.out.println();
		}
	}
}