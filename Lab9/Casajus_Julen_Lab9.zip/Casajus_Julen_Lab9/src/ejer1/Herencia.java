package ejer1;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Queue;

public class Herencia {
	
	private int numVertices;
	private ArrayList<NodoPersona> personas;

	public Herencia(int numVertices) {
		this.numVertices = numVertices;
		this.personas = new ArrayList<NodoPersona>();
	}
	
	public ArrayList<NodoPersona> getPersonas(){
		return this.personas;
	}
	
	// pre: distMax indica la distancia maxima de las personas a las que se repartira la herencia
	// pre: valor indica el valor de la herencia
	// post: el resultado es la cantidad que tocara a cada uno de los 
	//      beneficiarios de la herencia, que se calcula dividiendo la cantidad a 
	//      repartir a partes iguales entre las personas que se encuentran a 
	//      una distancia menor igual a distMax de la persona con nombre nomP.
	//      Devolvera -1 si la persona no existe o no tiene beneficiarios
	public int repartirHerencia(String nomP, int valor, int distMax) {
		NodoPersona p = null;
		
		for(int i = 0; i < numVertices; i++) {
			if(personas.get(i).getNombre().equals(nomP)) p = personas.get(i);
		}
		
		if(p == null) return -1;
		
		HashMap<NodoPersona, Integer> visitados = new HashMap<>();
		Queue<NodoPersona> cola = new LinkedList<>();
		cola.add(p);
		visitados.put(p, 0);
		int cont = 0;
		while(!cola.isEmpty()) {
			NodoPersona actual = cola.remove();
			int distActual = visitados.get(actual);
			if(distActual > 0) cont++;
			if(distActual < distMax) {
				for(NodoPersona pariente : actual.getParientes()) {
					if(!visitados.containsKey(pariente)) {
						cola.add(pariente);
						visitados.put(pariente, distActual+1);
					}
				}
			}
		}
		if(cont > 0) return valor / cont;
		else return -1;
	}
}