package ejer1;

import java.util.LinkedList;

public class NodoPersona {
	
	String nombre;
	LinkedList<NodoPersona> parientes;

	public NodoPersona(String nombre) {
		this.nombre = nombre;
		this.parientes = new LinkedList<NodoPersona>();
	}

	public void anadirPariente(NodoPersona pariente) {
		this.parientes.add(pariente);
		pariente.parientes.add(this);
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public LinkedList<NodoPersona> getParientes() {
		return parientes;
	}

	public void setParientes(LinkedList<NodoPersona> parientes) {
		this.parientes = parientes;
	}
}