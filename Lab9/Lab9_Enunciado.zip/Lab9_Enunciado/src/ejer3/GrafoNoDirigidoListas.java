package ejer3;



import java.util.ArrayList;

public class GrafoNoDirigidoListas<T> {
	
	int numNodos;
	ArrayList<Nodo<T>> nodos;

	public GrafoNoDirigidoListas() {
		this.numNodos = 0;
		nodos = new ArrayList<Nodo<T>>();
	}
	
	

	public void anadirNodo(Nodo<T> nodo) {
		nodos.add(nodo);
		this.numNodos++;
	}
	
	//Devuelve true si el grafo es conexo. Se pide implementar mediante recorrido en anchura
		public boolean esConexoAnchura() {
			return false; //CORREGIR SI NECESARIO
			
		}
	

		
		public void imprimirGrafo() {
			for (Nodo<T> nodo : nodos) {
				System.out.print(nodo.info.toString() + ": ");
				for (Nodo<T> ady : nodo.adyacentes) {
					System.out.print(ady.info.toString() + " ");
				}
				System.out.println();
			}
		}


}
