package ejer3;

import java.util.LinkedList;

public class Nodo<T> {
	
	T info;
	LinkedList<Nodo<T>> adyacentes;

	public Nodo(T info) {
		this.info = info;
		this.adyacentes = new LinkedList<Nodo<T>>();
	}
	
	

}
