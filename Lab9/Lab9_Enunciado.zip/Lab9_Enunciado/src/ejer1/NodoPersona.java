package ejer1;

import java.util.LinkedList;

public class NodoPersona {
	String nombre;
	
	LinkedList<NodoPersona> parientes;

	public NodoPersona(String nombre) {
		this.nombre = nombre;
		this.parientes = new LinkedList<NodoPersona>();
	}

	public void anadirPariente(NodoPersona pariente) {
		this.parientes.add(pariente);
		pariente.parientes.add(this);
	}
}
