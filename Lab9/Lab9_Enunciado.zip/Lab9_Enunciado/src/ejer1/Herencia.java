package ejer1;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;

public class Herencia {
	
	private int numVertices;
	private ArrayList<NodoPersona> personas;

	public Herencia(int numVertices) {
		this.numVertices = numVertices;
		this.personas = new ArrayList<NodoPersona>();
	}
	
	public ArrayList<NodoPersona> getPersonas(){
		return this.personas;
	}
	
	
	
	// pre:  distMax indica la distancia m�xima de las personas a las que se repartir� la herencia
	// pre: valor indica el valor de la herencia
	// post: el resultado es la cantidad que tocar� a cada uno de los 
	//      beneficiarios de la herencia, que se calcula dividiendo la cantidad a 
	//      repartir a partes iguales entre las personas que se encuentran a 
	//      una distancia menor igual a distMax de la persona con nombre nomP.
	//      Devolver� -1 si la persona no existe o no tiene beneficiarios
	public int repartirHerencia(String nomP, int valor, int distMax) {
		//TO DO
		return -1;//corregir si necesario
	}


}
