package ejer2;

import java.util.HashMap;
import java.util.LinkedList;

public class GrafoNoDirigidoMap<T> {
	HashMap<Nodo<T>, LinkedList<Nodo<T>>> hm;

	public HashMap<Nodo<T>, LinkedList<Nodo<T>>> getHm() {
		return hm;
	}

	public GrafoNoDirigidoMap() {
		hm = new HashMap<Nodo<T>, LinkedList<Nodo<T>>>();
	}
	
	
	
	
	public void fusionar(GrafoNoDirigidoMap<T> grafo2) {
		//TO DO
	}
	
	
	
	
	
	
	
	
	
	
	

	public void anadirNodo(Nodo<T> nodo) {
		this.hm.put(nodo, new LinkedList<Nodo<T>>());
	}


	public void anadirArista(Nodo<T> origen, Nodo<T> destino) {
		this.hm.get(origen).add(destino);
		this.hm.get(destino).add(origen);
	}

	public void imprimirGrafo() {
		for (Nodo<T> nodo : hm.keySet()) {
			System.out.print(nodo.info.toString() + ": ");
			for (Nodo<T> ady : hm.get(nodo)) {
				System.out.print(ady.info.toString() + " ");
			}
			System.out.println();
		}
	}


}
