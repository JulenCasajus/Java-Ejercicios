package ejer2;


import java.util.LinkedList;

public class PruebaEjer2 {

	public static void main(String[] args) {
	

		GrafoNoDirigidoMap<String> grafo = new GrafoNoDirigidoMap<String>();
		
		Nodo<String> nodoA = new Nodo<String>("A");
		Nodo<String> nodoB = new Nodo<String>("B");
		Nodo<String> nodoC = new Nodo<String>("C");
		Nodo<String> nodoD = new Nodo<String>("D");
		Nodo<String> nodoE = new Nodo<String>("E");

		grafo.anadirNodo(nodoA);
		grafo.anadirNodo(nodoB);
		grafo.anadirNodo(nodoC);
		grafo.anadirNodo(nodoD);
		grafo.anadirNodo(nodoE);
		
		grafo.anadirArista(nodoA, nodoB);
		grafo.anadirArista(nodoA, nodoC);
		grafo.anadirArista(nodoA, nodoE);
		grafo.anadirArista(nodoB, nodoC);
		grafo.anadirArista(nodoB, nodoD);
		grafo.anadirArista(nodoD, nodoE);
		
		System.out.println("Grafo 'this' antes de fusionar:");
		grafo.imprimirGrafo();

		
		GrafoNoDirigidoMap<String> grafo2 = new GrafoNoDirigidoMap<String>();		
		
		Nodo<String> nodoF = new Nodo<String>("F");
		Nodo<String> nodoH = new Nodo<String>("H");
		
		grafo2.anadirNodo(nodoB);
		grafo2.anadirNodo(nodoH);
		grafo2.anadirNodo(nodoF);
		grafo2.anadirNodo(nodoC);
		grafo2.anadirNodo(nodoE);
		
		grafo2.anadirArista(nodoB, nodoH);
		grafo2.anadirArista(nodoB, nodoF);
		grafo2.anadirArista(nodoB, nodoC);
		grafo2.anadirArista(nodoF, nodoH);
		grafo2.anadirArista(nodoF, nodoE);
		grafo2.anadirArista(nodoE, nodoC);

		System.out.println("\nGrafo2 antes de fusionar: ");
		grafo2.imprimirGrafo();
		grafo.fusionar(grafo2);
		System.out.println("\nGrafo 'this' despu�s de fusionarlo con grafo2: ");
		grafo.imprimirGrafo();

	}		
}
