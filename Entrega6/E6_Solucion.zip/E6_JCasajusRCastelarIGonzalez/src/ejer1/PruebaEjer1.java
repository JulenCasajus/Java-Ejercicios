package ejer1;

public class PruebaEjer1 {

	public static void main(String[] args) {		

		String textoNota, textoRevista;
		
		System.out.println("\n### PRUEBA 1 ###"); //true
		textoNota = "give me one million TONIGHT";
		textoRevista = "give me one million reasons to trust you tonight";
		comprobar(textoNota, textoRevista);
		
		System.out.println("\n### PRUEBA 2 ###"); //false
		textoNota = "I need diamonds";
		textoRevista = "you and I we are like diamonds in the sky";
		comprobar(textoNota, textoRevista);
		
		System.out.println("\n### PRUEBA 3 ###"); //false
		textoNota = "be quiet and be fast";
		textoRevista = "washing machines should be fast and quiet";
		comprobar(textoNota, textoRevista);
		
		System.out.println("\n### PRUEBA 4 ###"); //true
		textoNota = "give a lot of money tomorrow morning";
		textoRevista = "good morning money and give a lot of love tomorrow";
		comprobar(textoNota, textoRevista);
		
		//comprobacion frases vacias
		
		System.out.println("\n### PRUEBA 5 ###"); //true
		textoNota = "";
		textoRevista = "good morning money and give a lot of love tomorrow";
		comprobar(textoNota, textoRevista);
		
		System.out.println("\n### PRUEBA 5.1 ###"); //true
		textoNota = " ";
		textoRevista = "good morning money and give a lot of love tomorrow";
		comprobar(textoNota, textoRevista);
		
		System.out.println("\n### PRUEBA 6 ###"); //false
		textoNota = "give a lot of money tomorrow morning";
		textoRevista = "";
		comprobar(textoNota, textoRevista);
		
		System.out.println("\n### PRUEBA 6.1 ###"); //false
		textoNota = "give a lot of money tomorrow morning";
		textoRevista = " ";
		comprobar(textoNota, textoRevista);
		
		System.out.println("\n### PRUEBA 7 ###"); //true
		textoNota = "";
		textoRevista = "";
		comprobar(textoNota, textoRevista);
	}
	
	private static void comprobar(String textoNota, String textoRevista) {
		String[] palabrasNota, palabrasRevista;
        palabrasNota = textoNota.split("\\s+");
        palabrasRevista = textoRevista.split("\\s+");        
        System.out.println("palabrasNota: " + textoNota);
        System.out.println("palabrasRevista: " + textoRevista);
        System.out.println("Nota posible?: " + Secuestrador.notaPosible(palabrasNota, palabrasRevista));
	}
}