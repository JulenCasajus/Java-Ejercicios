package ejer1;

import java.util.HashMap;

public class Secuestrador {
	/**
	 * @param palabrasNota: palabras de la nota (una en cada posicion)
	 * @param palabrasRevista: palabras de la revista (una en cada posicion)
	 * @return true si la nota se puede escribir, false en caso contrario
	 */
    public static boolean notaPosible(String[] palabrasNota, String[] palabrasRevista) {
    	
        HashMap<String, Integer> hash = new HashMap<>();

        for(String palabra : palabrasRevista) {
            palabra = palabra.toLowerCase();
            hash.put(palabra, hash.getOrDefault(palabra, 0) + 1);
        } 
        for(String palabraNota : palabrasNota) {
        	if(palabraNota == "") return true; //caso especial: no hay nota
            palabraNota = palabraNota.toLowerCase();
            if(!hash.containsKey(palabraNota) || hash.get(palabraNota) == 0) return false;
            hash.put(palabraNota, hash.get(palabraNota) - 1);
        } 
        return true;
    }
}