package ejer2;

import java.util.ArrayList;

public class PruebaEjer2 {

	public static void main(String[] args) {
		Medico m1 = new Medico("Dr. Arana", 8, 45);
		Medico m2 = new Medico("Dra. Loidi", 9, 00);
		Medico m3 = new Medico("Dra. Urrutia", 9, 30);
		Medico m4 = new Medico("Dr. Alonso", 02, 33); //caso especial
		
		m1.anadirPaciente("Ane");
		m1.anadirPaciente("Jon");
		m1.anadirPaciente("Lidia");
		
		m2.anadirPaciente("Asier");
		m2.anadirPaciente("Jon");
	
		m3.anadirPaciente("Jon");
		m3.anadirPaciente("Oihana");
		m3.anadirPaciente("Sara");
		m3.anadirPaciente("Lidia");
		
		//casos especiales
		
		m4.anadirPaciente(""); 
		m4.anadirPaciente("#$%&");
		m4.anadirPaciente("Verstappen");

		ArrayList<Medico> medicos = new ArrayList<Medico>();
		medicos.add(m1);
		medicos.add(m2);
		medicos.add(m3);
		medicos.add(m4);
		
		Ambulatorio amb = new Ambulatorio();
		System.out.println(amb.asignarCitas(medicos));
		
		System.out.println("\n" + amb.asignarCitas(new ArrayList<Medico>())); //caso vacio
	}
}