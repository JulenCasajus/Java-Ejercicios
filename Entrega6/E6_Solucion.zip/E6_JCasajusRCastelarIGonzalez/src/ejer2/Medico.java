package ejer2;

import java.util.LinkedList;
import java.util.Queue;

public class Medico {
	
	private String nom;
	private Queue<String> pacientes; //cola con los nombres de los pacientes
	private int horaComienzo;
	private int minutoComienzo;

	public Medico(String nom, int horaComienzo, int minutoComienzo) {
		this.nom = nom;
		this.pacientes = new LinkedList<String>();
		this.horaComienzo = horaComienzo;
		this.minutoComienzo = minutoComienzo;		
	}
	
	public String getNom() {
		return nom;
	}

	public Queue<String> getPacientes() {
		return pacientes;
	}

	public int getHoraComienzo() {
		return horaComienzo;
	}

	public int getMinutoComienzo() {
		return minutoComienzo;
	}
	
	public void anadirPaciente(String paciente) {
		this.pacientes.add(paciente);
	}
	
	public String toString() {
		return (nom + ", " + horaComienzo + ":" + minutoComienzo);
	}
}