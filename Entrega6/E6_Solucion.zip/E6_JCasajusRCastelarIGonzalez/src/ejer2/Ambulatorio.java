package ejer2;

import java.util.ArrayList;
import java.util.HashMap;

public class Ambulatorio {

	public Ambulatorio() {
		// TODO Auto-generated constructor stub
	}
	
	public HashMap<String, ArrayList<Medico>> asignarCitas(ArrayList<Medico> medicos) {		
		
		HashMap<String, ArrayList<Medico>> hash = new HashMap<>();
		
		for (Medico medico : medicos) {
	        int hora = medico.getHoraComienzo();
	        int minuto = medico.getMinutoComienzo();
	        
	        for (String paciente : medico.getPacientes()) {
	        	ArrayList<Medico> citas = hash.getOrDefault(paciente, new ArrayList<>());
	            citas.add(new Medico(medico.getNom(), hora, minuto));
	            hash.put(paciente, citas);

	            minuto += 15;
	            if (minuto >= 60) {
	                hora++;
	                minuto = minuto % 60;
	            }
	        }
		}
		return hash;
	}
}