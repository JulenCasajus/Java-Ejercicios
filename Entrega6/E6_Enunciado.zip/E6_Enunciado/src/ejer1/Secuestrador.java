package ejer1;


public class Secuestrador {

    /**
   * @param palabrasNota: palabras de la nota (una en cada posici�n)
   * @param palabrasRevista: palabras de la revista (una en cada posici�n)
   * @return true si la nota se puede escribir, false en caso contrario
   */
    public static boolean notaPosible(String[] palabrasNota, String[] palabrasRevista) {
    	
    	//TO DO
    	
    	return false; //CORREGIR SI NECESARIO
    }


}
