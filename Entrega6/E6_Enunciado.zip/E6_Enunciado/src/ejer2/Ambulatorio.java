package ejer2;

import java.util.ArrayList;
import java.util.HashMap;

public class Ambulatorio {

	public Ambulatorio() {
		// TODO Auto-generated constructor stub
	}
	
	public HashMap asignarCitas(ArrayList<Medico> medicos){ //TO DO: COMPLETAR CABECERA: HashMap<XXX, ArrayList<XXX>>
		
		//TO DO
		return null; //CORREGIR SI NECESARIO
	}



}
