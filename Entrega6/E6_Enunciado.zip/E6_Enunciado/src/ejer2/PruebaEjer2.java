package ejer2;

import java.util.ArrayList;
import java.util.HashMap;

public class PruebaEjer2 {


	public static void main(String[] args) {
		Medico m1 = new Medico("Dr. Arana",8,45);
		Medico m2 = new Medico("Dra. Loidi",9,00);
		Medico m3 = new Medico("Dra. Urrutia",9,30);
		
		m1.anadirPaciente("Ane");
		m1.anadirPaciente("Jon");
		m1.anadirPaciente("Lidia");
		
		m2.anadirPaciente("Asier");
		m2.anadirPaciente("Jon");
	
		
		m3.anadirPaciente("Jon");
		m3.anadirPaciente("Oihana");
		m3.anadirPaciente("Sara");
		m3.anadirPaciente("Lidia");
		
		ArrayList<Medico> medicos = new ArrayList<Medico>();
		medicos.add(m1);
		medicos.add(m2);
		medicos.add(m3);
		
		Ambulatorio amb = new Ambulatorio();
		System.out.println(amb.asignarCitas(medicos));

	}

}
