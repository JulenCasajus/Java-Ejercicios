package ejer3;
import java.util.HashMap;

public class Hashtags {

	public Hashtags() {
		// TODO Auto-generated constructor stub
	}
	
	public void emparejamientoCorrecto(String hashtags, String palabras) {
		
		HashMap<String, String> hash1 = new HashMap<>();
		HashMap<String, String> hash2 = new HashMap<>();
		
		String[] sp1 = hashtags.split("\\s+");
		String[] sp2 = palabras.split("\\s+");
		
		if(sp1.length != sp2.length) {
			System.out.println("El emparejamiento no es correcto.");
			return;
		}
		
		for(int i = 0 ; i < sp1.length; i++) {
			if(!sp2[i].equals(hash1.getOrDefault(sp1[i], sp2[i]))) {
				System.out.println("El emparejamiento no es correcto.");
				return;
			} hash1.put(sp1[i], sp2[i]);
			if(!sp1[i].equals(hash2.getOrDefault(sp2[i], sp1[i]))) {
				System.out.println("El emparejamiento no es correcto.");
				return;
			} hash2.put(sp2[i], sp1[i]);
		}
		
		System.out.println("El emparejamiento es correcto.");
		
		for(String s : hash1.keySet()) {
			if(s != "") System.out.println(s + "->" + hash1.get(s));
		}
	}
}