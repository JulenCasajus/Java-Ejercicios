package ejer2;

public class Hora implements Comparable<Hora> {

	private int hora;
	private int minuto;

	public Hora(int hora, int minuto) {
		this.hora = hora;
		this.minuto = minuto;
	}
	
	public int getHora() {
		return hora;
	}

	public int getMinuto() {
		return minuto;
	}

	@Override
	public int compareTo(Hora o) {
		// TODO Auto-generated method stub
		if(this.hora == o.hora) {
			if(this.minuto == o.minuto) return 0;
			else if(this.minuto < o.minuto) return -1;
			else return 1;
		}
		if(this.hora < o.hora) return -1;
		else return 1;
	}
	
	@Override
	public String toString() {
		if(minuto >= 10) return this.hora + ":" + this.minuto;
		else return this.hora + ":0" + minuto;
	}
}