package ejer2;

import java.util.ArrayList;

public class PruebaAulario {

	public PruebaAulario() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		Aulario aulario = new Aulario();
		ArrayList<Solicitud> solicitudes = new ArrayList<Solicitud>();
		
		System.out.println("Prueba 1:\n"); //no es posible porque MEI se solapa con PB en el aula 2.6
		
		ArrayList<String> aulasEDA = new ArrayList<String>();
		aulasEDA.add("2.5");
		aulasEDA.add("2.6");
		aulasEDA.add("2.7");
		solicitudes.add(new Solicitud("EDA", aulasEDA, new Hora(9,0), new Hora(11,0)));
		
		ArrayList<String> aulasPB = new ArrayList<String>();
		aulasPB.add("1.9");
		aulasPB.add("2.6");
		solicitudes.add(new Solicitud("PB", aulasPB, new Hora(12,0), new Hora(14,0)));
		
		ArrayList<String> aulasMEI = new ArrayList<String>();
		aulasMEI.add("1.2");
		aulasMEI.add("2.6");
		solicitudes.add(new Solicitud("MEI", aulasMEI, new Hora(13,0), new Hora(17,0)));
		
		ArrayList<String> aulasDBD = new ArrayList<String>();
		aulasDBD.add("1.9");
		solicitudes.add(new Solicitud("DBD", aulasDBD, new Hora(15,0), new Hora(17,0)));
		
		for(Solicitud s : solicitudes) {
			System.out.println(s);
		}		

		System.out.println("Es posible?: " + aulario.verificarSolicitudes(solicitudes));
		
		System.out.println("\nPrueba 2:\n"); //igual que el anterior pero modificando la hora de MEI para que sea posible
		solicitudes = new ArrayList<Solicitud>();
		solicitudes.add(new Solicitud("EDA", aulasEDA, new Hora(9,0), new Hora(11,0)));
		solicitudes.add(new Solicitud("PB", aulasPB, new Hora(12,0), new Hora(14,0)));
		solicitudes.add(new Solicitud("MEI", aulasMEI, new Hora(14,1), new Hora(17,0)));
		solicitudes.add(new Solicitud("DBD", aulasDBD, new Hora(15,0), new Hora(17,0)));

		for(Solicitud s : solicitudes) {
			System.out.println(s);
		}
		
		System.out.println("Es posible?: " + aulario.verificarSolicitudes(solicitudes));
		
		
		
		System.out.println("\nPrueba 3:\n");
		
		System.out.println("Es posible?: " + aulario.verificarSolicitudes(new ArrayList<Solicitud>())); //caso vacio
	}
}