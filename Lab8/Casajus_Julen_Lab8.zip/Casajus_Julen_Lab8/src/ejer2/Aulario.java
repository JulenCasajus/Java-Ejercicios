package ejer2;

import java.util.ArrayList;
import java.util.HashMap;

public class Aulario {

	public Aulario() {
		// TODO Auto-generated constructor stub
	}
	
	public boolean verificarSolicitudes(ArrayList<Solicitud> solicitudes) {
		
		HashMap<String, Hora> hash = new HashMap<>();
		
		if(solicitudes.isEmpty()) return true; //caso especial: no hay solicitudes
		
		for(Solicitud asignatura : solicitudes) {
			for(String aula : asignatura.aulas()) {
				if(hash.containsKey(aula) && hash.get(aula).compareTo(asignatura.getHoraIni()) >= 0) return false;
				hash.put(aula, asignatura.getHoraFin());
			}
		} return true;
	}
}