package ejer2;

import java.util.ArrayList;

public class Solicitud {
	
	private String asignatura;
	private ArrayList<String> aulas;
	private Hora horaIni;
	private Hora horaFin;

	public Solicitud(String asignatura, ArrayList<String> aulas, Hora horaIni, Hora horaFin) {
		this.asignatura = asignatura;
		this.aulas = aulas;
		this.horaIni = horaIni;
		this.horaFin = horaFin;
	}
	
	public String getAsignatura() {
		return asignatura;
	}

	public Hora getHoraIni() {
		return horaIni;
	}

	public Hora getHoraFin() {
		return horaFin;
	}
	
	public ArrayList<String> aulas() {
		return this.aulas;
	}
	
	@Override
	public String toString() {
		return asignatura + ":\n\tAulas:" + aulas + "\n\tDe " + horaIni + " a " + horaFin;
	}
}