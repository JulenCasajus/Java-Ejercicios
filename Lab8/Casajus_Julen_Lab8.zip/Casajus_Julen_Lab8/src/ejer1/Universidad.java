package ejer1;

import java.util.HashMap;
import java.util.LinkedList;

public class Universidad {

	public HashMap<Integer, LinkedList<String>> transformar (HashMap<String, LinkedList<Integer>> alumnos){
		HashMap<Integer, LinkedList<String>> hash = new HashMap<> ();
		
		for(String alumno : alumnos.keySet()) {
			for(Integer asignatura : alumnos.get(alumno)) {
				LinkedList<String> listaAsignaturas = hash.getOrDefault(asignatura, new LinkedList<String>());
				listaAsignaturas.add(alumno);
				hash.put(asignatura, listaAsignaturas);
			}
		}
		return hash;
	}
}