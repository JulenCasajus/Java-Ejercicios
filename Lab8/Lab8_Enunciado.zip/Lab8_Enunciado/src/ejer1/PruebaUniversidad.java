package ejer1;

import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;

public class PruebaUniversidad {

	public static void main(String[] args) {
		HashMap<String, LinkedList<Integer>> alumnos = new HashMap<String, LinkedList<Integer>>();
		
		LinkedList<Integer> l1 = new LinkedList<Integer>(Arrays.asList(11167, 27539, 43700, 62101));
		alumnos.put("aamutxastegi001", l1);
		
		LinkedList<Integer> l2 = new LinkedList<Integer>(Arrays.asList(22654, 23132, 32649, 43700, 92177));
		alumnos.put("lzeberio003", l2);
		
		LinkedList<Integer> l3 = new LinkedList<Integer>(Arrays.asList(21350, 22654, 23132, 26031, 42692, 62101));
		alumnos.put("iuriarte012", l3);
		
		LinkedList<Integer> l4 = new LinkedList<Integer>(Arrays.asList(26031, 32020, 32643, 32649, 33627, 43700));
		alumnos.put("xandonegi002", l4);
		
		LinkedList<Integer> l5 = new LinkedList<Integer>(Arrays.asList(22654, 33627, 43700, 62101, 83119, 93721));
		alumnos.put("mgutierrez011", l5);
		
		LinkedList<Integer> l6 = new LinkedList<Integer>(Arrays.asList(27539));
		alumnos.put("ialbisu007", l6);
		
		LinkedList<Integer> l7 = new LinkedList<Integer>(Arrays.asList(11167, 22654, 27539, 42692, 54543, 62101, 93721));
		alumnos.put("egartzia043", l7);
		
		Universidad u = new Universidad();
		HashMap<Integer, LinkedList<String>> asignaturas = u.transformar(alumnos);
		
		for(Integer asig: asignaturas.keySet()) {
			System.out.println(asig+": "+asignaturas.get(asig).toString());
		}

	}

}
