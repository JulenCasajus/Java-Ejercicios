package ejer1;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;

public class Universidad {

	public HashMap<Integer, LinkedList<String>> transformar (HashMap<String, LinkedList<Integer>> alumnos){
		//TO DO
		return null; //modificar si necesario
	}
	
	

}
