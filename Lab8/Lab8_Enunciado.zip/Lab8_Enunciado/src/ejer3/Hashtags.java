package ejer3;



public class Hashtags {

	public Hashtags() {
		// TODO Auto-generated constructor stub
	}
	
	
	public void emparejamientoCorrecto(String hashtags, String palabras) {
		String[] sp1 = hashtags.split("\\s+");
		String[] sp2 = palabras.split("\\s+");

		//TO DO
	}

}
