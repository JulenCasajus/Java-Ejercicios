package ejer3;


public class PruebaHashtags {

	public PruebaHashtags() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		Hashtags ej = new Hashtags();
		
		String s1, s2;
		int i=1;
		
		System.out.println("Prueba "+i+":");
		i++;
		s1 = "#a #b #b #a";
		s2 = "cat dog dog cat";		
		System.out.println("Hashtags: "+s1);
		System.out.println("Palabras: "+s2);
		ej.emparejamientoCorrecto(s1, s2);
		System.out.println("\n");
		
		
		System.out.println("Prueba "+i+":");
		i++;
		s1 = "#a #b #b #a";
		s2 = "cat cat dog cat";		
		System.out.println("Hashtags: "+s1);
		System.out.println("Palabras: "+s2);
		ej.emparejamientoCorrecto(s1, s2);
		System.out.println("\n");
		
		System.out.println("Prueba "+i+":");
		i++;
		s1 = "#a #b #a #a";
		s2 = "cat dog cow cat";		
		System.out.println("Hashtags: "+s1);
		System.out.println("Palabras: "+s2);
		ej.emparejamientoCorrecto(s1, s2);
		System.out.println("\n");
		
		System.out.println("Prueba "+i+":");
		i++;
		s1 = "";
		s2 = "";		
		System.out.println("Hashtags: "+s1);
		System.out.println("Palabras: "+s2);
		ej.emparejamientoCorrecto(s1, s2);
		System.out.println("\n");
		
		System.out.println("Prueba "+i+":");
		i++;
		s1 = "#a #b #c #d #e #b #b #d #a";
		s2 = "ant bird cat dog elephant bird bird dog ant";		
		System.out.println("Hashtags: "+s1);
		System.out.println("Palabras: "+s2);
		ej.emparejamientoCorrecto(s1, s2);
		System.out.println("\n");

	}

}
