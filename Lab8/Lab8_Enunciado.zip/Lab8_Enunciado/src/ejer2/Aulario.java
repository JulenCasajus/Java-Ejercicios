package ejer2;

import java.util.ArrayList;
import java.util.HashMap;


public class Aulario {

	public Aulario() {
		// TODO Auto-generated constructor stub
	}
	
	public boolean verificarSolicitudes(ArrayList<Solicitud> solicitudes) {
		
		//TO DO
		return false; //corregir si necesario
	}
	

	

}
