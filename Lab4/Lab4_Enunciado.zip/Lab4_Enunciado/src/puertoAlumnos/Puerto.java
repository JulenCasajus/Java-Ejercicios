package puertoAlumnos;

import java.util.Queue;


public class Puerto {
	//private XXXXX parcelas; //TO DO: escoger la estructura adecuada para representar las parcelas y descomentar
	private static final int NUMPARCELAS = 10;
	

	public Puerto() {
		//TO DO: creaci�n de las parcelas
	}
	
	//TO DO: simularMovimientos: simula los movimientos que hace la gr�a para desplazar los contenedores,
	// actualizando el contenido de las parcelas. Escribe por pantalla cada movimiento efectuado.
	public void simularMovimientos(Queue<Movimiento> movimientos) {
		
		//TO DO
	}


}
