package impresorasAlumnos;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class CentroDeCalculo {
	//private XXXXXX impresoras; //TO DO: escoger la estructura para representar las impresoras y descomentar

	public CentroDeCalculo() {
		//TO DO: creaci�n de las impresoras
	}
	
	
	//TO DO: completar simularEventos: simula los eventos del fichero y al finalizar imprime los nombres de los archivos que quedan en cada impresora
	public void simularEventos(String nomFich) throws IOException {
		
		Scanner sc = new Scanner(new File(nomFich));		
		String[] datos;

		while(sc.hasNextLine()) {
			datos = sc.nextLine().split("\\s+");
			switch(datos[0]) {
			case "S": 
				      //TO DO
				      break;
			case "I": 
				      //TO DO
				      break;
			case "P": 
				      //TO DO
				      break;
			case "F": 
				     //TO DO
				     break;
			default: break;
			}
		}
		sc.close();
		//TO DO
	}


}
