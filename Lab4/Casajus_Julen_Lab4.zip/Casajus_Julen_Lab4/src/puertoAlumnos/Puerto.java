package puertoAlumnos;

import java.util.*;

public class Puerto {
	
	private Stack<String>[] parcelas; 
	private static final int NUMPARCELAS = 10;

	public Puerto() {
		parcelas = new Stack [NUMPARCELAS]; 
		
		for (int i = 0; i < NUMPARCELAS; i++) {
			parcelas[i] = new Stack<>();
		}
	}
	
	public void simularMovimientos(Queue<Movimiento> movimientos) {
		
		while(!movimientos.isEmpty()) {
			Movimiento movimiento = movimientos.remove();	
			
			if (movimiento.getTipo() == 'D') {
				
				if(parcelas[movimiento.getParcela()].size() == 4) {
					System.out.println("La parcela " + movimiento.getParcela() + " está llena. " + movimiento.getContenedor() + " Vuelve a la cola");
					movimientos.add(movimiento);
				} else {
					parcelas[movimiento.getParcela()].add(movimiento.getContenedor());//Anadimos a la pila
					System.out.println("Descargar " + movimiento.getContenedor() + " en la parcela " + movimiento.getParcela());
				}
			} else {
				if(parcelas[movimiento.getParcela()].peek().equals(movimiento.getContenedor())) {//El elemento que queremos coger está en la cima
					System.out.println("Cargar " + movimiento.getContenedor() + " desde la parcela " + movimiento.getParcela());
					parcelas[movimiento.getParcela()].pop();
				} else { 
					while(!parcelas[movimiento.getParcela()].peek().equals(movimiento.getContenedor())) {
						System.out.println("Mover " + parcelas[movimiento.getParcela()].peek() + " de parcela " + movimiento.getParcela() + " a la parcela 0");
						parcelas[0].push(parcelas[movimiento.getParcela()].pop());
					}
					
					System.out.println("Cargar " + movimiento.getContenedor() + " desde la parcela " + movimiento.getParcela());
					parcelas[movimiento.getParcela()].pop();
					
					while (parcelas[0].size() != 0) {
						System.out.println("Mover " + parcelas[0].peek() + " de parcela 0 a parcela " + movimiento.getParcela());
						parcelas[movimiento.getParcela()].push(parcelas[0].pop());
					}
				}
			}
		}
	}
}