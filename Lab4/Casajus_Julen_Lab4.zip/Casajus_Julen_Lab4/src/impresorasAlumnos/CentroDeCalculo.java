package impresorasAlumnos;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class CentroDeCalculo {
	private Queue<String>[] impresoras;

	public CentroDeCalculo() {
		impresoras = (LinkedList<String>[])(new LinkedList[5]);
		for(int i = 0; i < 5; i++) {
			impresoras[i] = new LinkedList<>();
		}
	}

	public void simularEventos(String nomFich) throws IOException {
		
		Scanner sc = new Scanner(new File(nomFich));		
		String[] datos;
		boolean error = false;

		while(sc.hasNextLine()) {
			datos = sc.nextLine().split("\\s+");
			switch(datos[0]) {
			case "S": 
				try{
					if(!error) {
						impresoras[Integer.parseInt(datos[1])].add(datos[2]);
				      } else impresoras[4].add(datos[2]);
					}
				catch (NumberFormatException nfe) {
					System.out.println("Numero de impresora invalido");
				}
				break;
			case "I": 
				try{
					//imprimir(Integer.parseInt(datos[1])); suponemos que existe un programa para imprimir
					impresoras[Integer.parseInt(datos[1])].remove();
			     }
			     catch (NumberFormatException nfe) {  
			    	 System.out.println("Numero de impresora invalido");
			     }
				break;
			case "P": 
				error = true;
	            for (int i = 0; i < 4; i++) {
	                while(!impresoras[i].isEmpty()) {
	                    impresoras[4].add(impresoras[i].remove());
	                }
	            }
				break;
			case "F": 
				error = false;
				break;
			default: break;
			}
		}
		sc.close();
		for(int i = 0; i < 5; i++) {
			System.out.print("Impresora " + i + ": <");
			while(!impresoras[i].isEmpty()) {
				System.out.print(impresoras[i].remove() + " ");
			}
			System.out.println(">");
		}
	}
}