package ejer6;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;

public class Aulario {

	public Aulario() {
		// TODO Auto-generated constructor stub
	}
	
	public HashMap<String, LinkedList<Reserva>> crearTablaReservas(ArrayList<Solicitud> solicitudes){
		//TO DO
		return null; //MODIFICAR SI NECESARIO
	}
	


}
