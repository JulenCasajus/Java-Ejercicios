package ejer6;

public class Reserva {
	
	private String asignatura;
	private int semana;
	private char diasemana;
	private String hora;

	public Reserva(String asignatura, int semana, char diasemana, String hora) {
		this.asignatura = asignatura;
		this.semana = semana;
		this.diasemana = diasemana;
		this.hora = hora;
	}
	
	public String getAsignatura() {
		return asignatura;
	}

	public int getSemana() {
		return semana;
	}

	public char getDiasemana() {
		return diasemana;
	}

	public String getHora() {
		return hora;
	}
	
	@Override
	public String toString() {
		return "<"+this.asignatura+","+this.semana+","+this.diasemana+","+this.hora+">";
	}

}
