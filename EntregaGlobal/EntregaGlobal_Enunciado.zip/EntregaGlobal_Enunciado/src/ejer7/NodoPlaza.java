package ejer7;

import java.util.LinkedList;

public class NodoPlaza {
	String nombre;
	int numCamaras;
	LinkedList<NodoPlaza> adyacentes; //plazas adyacentes

	public NodoPlaza(String nombre, int numCamaras) {
		this.nombre = nombre;
		this.numCamaras = numCamaras;
		this.adyacentes = new LinkedList<NodoPlaza>();
	}
	
	

}
