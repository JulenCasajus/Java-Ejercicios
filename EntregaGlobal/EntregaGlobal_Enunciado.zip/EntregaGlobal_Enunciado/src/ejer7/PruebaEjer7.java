package ejer7;

public class PruebaEjer7 {

	public static void main(String[] args) {
		
		GrafoPlazas g = new GrafoPlazas();
		
		NodoPlaza zaragoza = new NodoPlaza("zaragoza",0);
		NodoPlaza cervantes = new NodoPlaza("cervantes",0);
		NodoPlaza easo = new NodoPlaza("easo",0);
		NodoPlaza consti = new NodoPlaza("consti",3);
		NodoPlaza gipuzkoa = new NodoPlaza("gipuzkoa",0);
		NodoPlaza buenp = new NodoPlaza("buenp",5);
		NodoPlaza pioxii = new NodoPlaza("pioxii",0);
		NodoPlaza portutxo = new NodoPlaza("portutxo",0);
		NodoPlaza zuloaga = new NodoPlaza("zuloaga",0);
		NodoPlaza okendo = new NodoPlaza("okendo",2);
		NodoPlaza cataluna = new NodoPlaza("cataluna",0);
		NodoPlaza zuhaizti = new NodoPlaza("zuhaizti",0);
		NodoPlaza hirutxulo = new NodoPlaza("hirutxulo",0);
		
		g.anadirNodo(zaragoza);
		g.anadirNodo(cervantes);
		g.anadirNodo(easo);
		g.anadirNodo(consti);
		g.anadirNodo(gipuzkoa);
		g.anadirNodo(buenp);
		g.anadirNodo(pioxii);
		g.anadirNodo(portutxo);
		g.anadirNodo(zuloaga);
		g.anadirNodo(okendo);
		g.anadirNodo(cataluna);
		g.anadirNodo(zuhaizti);
		g.anadirNodo(hirutxulo);
		
		g.anadirArista(zaragoza, cervantes);
		g.anadirArista(zaragoza, buenp);
		g.anadirArista(zaragoza, easo);
		g.anadirArista(cervantes, consti);
		g.anadirArista(cervantes, gipuzkoa);
		g.anadirArista(cervantes, buenp);
		g.anadirArista(easo, buenp);
		g.anadirArista(easo,pioxii);
		g.anadirArista(easo, portutxo);
		g.anadirArista(consti, zuloaga);
		g.anadirArista(gipuzkoa, okendo);
		g.anadirArista(buenp, okendo);
		g.anadirArista(buenp, zuhaizti);
		g.anadirArista(buenp, pioxii);
		g.anadirArista(pioxii, zuhaizti);
		g.anadirArista(portutxo, hirutxulo);
		g.anadirArista(okendo, cataluna);
		g.anadirArista(okendo, zuhaizti);
		g.anadirArista(cataluna, zuhaizti);
		g.anadirArista(zuhaizti, hirutxulo);
		
		System.out.println("Zaragoza->Zuhaizti: "+g.huida(zaragoza, zuhaizti));
		System.out.println("Zuloaga->Gipuzkoa: "+g.huida(zuloaga, gipuzkoa));

	}

}
