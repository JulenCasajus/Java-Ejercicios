package ejer7;

import java.util.ArrayList;



public class GrafoPlazas {
	private int numNodos; //n� de nodos del grafo
	private ArrayList<NodoPlaza> nodos; //nodos del grafo
	
		
	public GrafoPlazas() {
		this.numNodos = 0;
		this.nodos = new ArrayList<NodoPlaza>();
	}
	
      //pre: las plazas con nombre origen y destino est�n en el grafo
      //pre: no hay c�maras en origen y destino
	public int huida(NodoPlaza origen, NodoPlaza destino) {	
		//TO DO
		return -1; //MODIFICAR SI NECESARIO
	}
	
	
	
	
	 ///////// AUXILIARES PARA PRUEBAS (NO MODIFICAR) ////////////////////
	
	public void anadirNodo(NodoPlaza nodo) {
		this.nodos.add(nodo);
		this.numNodos++;
	}
	
	public void anadirArista(NodoPlaza origen, NodoPlaza destino) {
		origen.adyacentes.add(destino);
		destino.adyacentes.add(origen);
	}
}
