package ejer2;

public class PruebaEjer2 {

	public PruebaEjer2() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		DoublyLinkedList<Integer> lista1 = new DoublyLinkedList<Integer>();
		lista1.addLast(8);
		lista1.addLast(5);
		System.out.println("Lista original: ");
    	System.out.print("Lista al derecho: ");
    	lista1.imprimirAlDerecho();
       	System.out.print("Lista al reves: ");
		lista1.imprimirAlReves();

		System.out.println("==================================");
		System.out.println("Prueba #1: intercambiarConSig(8)");
		lista1.intercambiarConSig(8);
    	System.out.print("Lista al derecho: ");
    	lista1.imprimirAlDerecho();
       	System.out.print("Lista al reves: ");
		lista1.imprimirAlReves();
				
		lista1.addLast(4);
		lista1.addLast(2);
		lista1.addLast(3);
		lista1.addLast(9);
		lista1.addLast(4);
		lista1.addLast(7);		
		lista1.addLast(6);
		
		System.out.println();
		System.out.println("Tras a�adir varios elementos: ");
    	System.out.print("Lista al derecho: ");
    	lista1.imprimirAlDerecho();
       	System.out.print("Lista al reves: ");
		lista1.imprimirAlReves();

		System.out.println("==================================");
		System.out.println("Prueba #2: intercambiarConSig(4)");
		lista1.intercambiarConSig(4);
    	System.out.print("Lista al derecho: ");
    	lista1.imprimirAlDerecho();
       	System.out.print("Lista al reves: ");
		lista1.imprimirAlReves();

		//TO DO: completar con casos de prueba significativos
	}




	

}
