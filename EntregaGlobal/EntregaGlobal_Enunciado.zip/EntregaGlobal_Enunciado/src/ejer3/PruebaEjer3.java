package ejer3;

import java.util.ArrayList;

public class PruebaEjer3 {

	public PruebaEjer3() {
		// TODO Auto-generated constructor stub
	}
	
	public static void main(String[] args) {
		Peaje p = new Peaje(4);
		p.registro.get(0).add(new Ticket("1234-fkb",8,200,10000));
		p.registro.get(0).add(new Ticket("5678-dbs",3,500,18000));
		p.registro.get(0).add(new Ticket("1111-twc",2,1002,33500));
		p.registro.get(1).add(new Ticket("2222-ldb",16,80,3000));
		p.registro.get(1).add(new Ticket("5555-hpm",1,850,25000));
		p.registro.get(1).add(new Ticket("9999-vdf",20,2200,90000));
		p.registro.get(2).add(new Ticket("9876-lvk",4,250,10000));
		p.registro.get(3).add(new Ticket("4321-szp",5,510,18000));
		p.registro.get(3).add(new Ticket("0000-nyd",6,900,33500));
		p.registro.get(3).add(new Ticket("4545-plk",1,2310,33500));
		
		ArrayList<Ticket> lista =p.infractores();
		System.out.println("Los infractores son:");
		for(Ticket t:lista) {
			t.imprimir();
		}
	
	}

}
