package ejer3;

public class Ticket { // suponemos getters y setters
	String matricula;
	double tEntrada; // en qu� instante (en segundos) cogi� el ticket
	double tPeaje; // en qu� instante (en segundos) ha llegado al peaje
	double distanciaRecorrida; // distancia recorrida desde que cogi� el
//ticket hasta que ha llegado al peaje (en metros).
	
	public Ticket(String matricula, double tEntrada, double tPeaje, double distanciaRecorrida) {
		this.matricula = matricula;
		this.tEntrada = tEntrada;
		this.tPeaje = tPeaje;
		this.distanciaRecorrida = distanciaRecorrida;
	}
	
	public void imprimir() {
		double velocidad = (distanciaRecorrida/1000)/((tPeaje-tEntrada)/3600);
		System.out.println("Matr�cula: "+matricula+": "+velocidad+"km/h");
	}
}
