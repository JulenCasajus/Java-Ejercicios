package ejer3;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

public class Peaje { // suponemos getters y setters
	int numCabinas; // n� de cabinas del peaje
	ArrayList<Queue<Ticket>> registro; // Estructura que registra los
//tickets de todos los coches que llegan al peaje. Cada elemento (cola)
//del ArrayList hace referencia a una cabina y guarda los tickets de
//los coches que llegaron a dicha cabina, ordenados en base a tPeaje.
	
	
	public Peaje(int numCabinas) {
		//TO DO
	}
	
	public ArrayList<Ticket> infractores( ) {
		//TO DO
		return null; //CORREGIR SI NECESARIO
	} 
	
	
	
}