package ejer1;



public class Cola {
	
	private Nodo first;
	private Nodo last;
	
	public int size() {
		int cont = 0;
		Nodo actual = first;
		while(actual!=null) {
			cont++;
			actual = actual.next;
		}
		return cont;
	}

	public boolean adelantar(int elem, int n) {
		
		//TO DO
		return false; //CORREGIR SI NECESARIO
		
	}
	
	
	 ///////// AUXILIARES PARA PRUEBAS (NO MODIFICAR) ////////////////////
	
	
	public void imprimirAlDerecho() {
		Nodo aux = first;
		while(aux!=null) {
			System.out.print(aux.info+" ");
			aux = aux.next;
		}
		System.out.println();
	}
	
	

}
