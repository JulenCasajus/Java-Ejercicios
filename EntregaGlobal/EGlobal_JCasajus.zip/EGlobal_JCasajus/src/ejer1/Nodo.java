package ejer1;

public class Nodo {
	
	int info;
	Nodo next;

	public Nodo(int info) {
		this.info = info;
	}
}