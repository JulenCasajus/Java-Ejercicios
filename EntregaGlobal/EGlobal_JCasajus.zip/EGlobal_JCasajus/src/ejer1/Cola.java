package ejer1;

public class Cola {
	
	private Nodo first;
	private Nodo last;
	
	public int size() {
		int cont = 0;
		Nodo actual = first;
		while(actual != null) {
			cont++;
			actual = actual.next;
		}
		return cont;
	}

	public boolean adelantar(int elem, int n) {
		
		if((first == null && n > 0) || n < 0) return false;
		
		if(first == null && n == 0) {
			first = new Nodo(elem);
			last = first;
			return true;
		}
		
		Nodo nuevo = new Nodo(elem);
		
		if(n == 0) {
			last.next = nuevo;
			last = last.next;
			return true;
		}
		
		Nodo aux1 = first;
		Nodo aux2 = first;
		
		for(int i = 0; i < n; i++) {
			if(aux2 == null) return false;
			aux2 = aux2.next;
	    }
		
		if(aux2 == null) {
			nuevo.next = first;
			first = nuevo;
			return true;
		}
		
		while(aux2.next != null) {
			aux1 = aux1.next;
			aux2 = aux2.next;
		}

		nuevo.next = aux1.next;
		aux1.next = nuevo;

		return true;
	}
	
	 ///////// AUXILIARES PARA PRUEBAS (NO MODIFICAR) ////////////////////
	
	public void imprimirAlDerecho() {
		Nodo aux = first;
		while(aux != null) {
			System.out.print(aux.info + " ");
			aux = aux.next;
		}
		System.out.println();
	}
}