package ejer1;

public class PruebaEjer1 {

	public PruebaEjer1() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		
		Cola cola = new Cola();
		cola.imprimirAlDerecho();	
		
		System.out.println("adelantar(3,3): " + cola.adelantar(3,3)); //false
		cola.imprimirAlDerecho(); //
		
		System.out.println("adelantar(1,0): " + cola.adelantar(1,0)); //true
		cola.imprimirAlDerecho(); //1		

		System.out.println("adelantar(4,0): " + cola.adelantar(4,0)); //true 
		cola.imprimirAlDerecho(); //1 4
		
		System.out.println("adelantar(5,2): " + cola.adelantar(5,2)); //true 
		cola.imprimirAlDerecho(); //5 1 4
		
		System.out.println("adelantar(8,4): " + cola.adelantar(8,4)); //false
		cola.imprimirAlDerecho(); //5 1 4
		
		System.out.println("adelantar(8,3): " + cola.adelantar(8,3)); //true
		cola.imprimirAlDerecho(); //8 5 1 4
		
		System.out.println("adelantar(6,3): " + cola.adelantar(6,3)); //true
		cola.imprimirAlDerecho(); //8 6 5 1 4
	}	
}