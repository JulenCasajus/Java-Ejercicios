package ejer3;

public class Ticket { //suponemos getters y setters
	
	String matricula;
	double tEntrada; //en que instante (en segundos) cogio el ticket
	double tPeaje; //en que instante (en segundos) ha llegado al peaje
	double distanciaRecorrida; // distancia recorrida desde que cogio el
	//ticket hasta que ha llegado al peaje (en metros).
	
	public Ticket(String matricula, double tEntrada, double tPeaje, double distanciaRecorrida) {
		this.matricula = matricula;
		this.tEntrada = tEntrada;
		this.tPeaje = tPeaje;
		this.distanciaRecorrida = distanciaRecorrida;
	}
	
	public void imprimir() {
		double velocidad = (distanciaRecorrida / 1000) / ((tPeaje - tEntrada) / 3600);
		System.out.println("Matricula: " + matricula + ": " + velocidad + "km/h");
	}
}