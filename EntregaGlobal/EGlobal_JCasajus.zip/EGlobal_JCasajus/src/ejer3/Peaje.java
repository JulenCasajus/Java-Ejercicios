package ejer3;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

public class Peaje { //suponemos getters y setters
	int numCabinas; //numero de cabinas del peaje
	ArrayList<Queue<Ticket>> registro; // Estructura que registra los
	//tickets de todos los coches que llegan al peaje. Cada elemento (cola)
	//del ArrayList hace referencia a una cabina y guarda los tickets de
	//los coches que llegaron a dicha cabina, ordenados en base a tPeaje.
	
	public Peaje(int numCabinas) {
		this.numCabinas = numCabinas;
		registro = new ArrayList<Queue<Ticket>>();
		for(int i = 0; i < numCabinas; i++) {
			registro.add(new LinkedList<Ticket>());
		}
	}
	
	public ArrayList<Ticket> infractores() {
		
		Queue<Ticket> listaTickets = new LinkedList<Ticket>();
		ArrayList<Ticket> listaInfractores = new ArrayList<Ticket>();
		int j;
		
		for(int i = 0; i < numCabinas; i++) {
			listaTickets = registro.get(i);
			while(!listaTickets.isEmpty()) {
				Ticket T = listaTickets.remove();
				if((T.distanciaRecorrida / 1000) / ((T.tPeaje - T.tEntrada) / 3600) > 120) {
					j = 0;
					while(j < listaInfractores.size() && T.tPeaje > listaInfractores.get(j).tPeaje) {
						j++;
					}
					listaInfractores.add(j, T);
				}
			}	
		}	
		return listaInfractores;
	}
}