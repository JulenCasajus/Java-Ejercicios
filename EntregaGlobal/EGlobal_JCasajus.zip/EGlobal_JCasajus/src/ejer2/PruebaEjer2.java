package ejer2;

public class PruebaEjer2 {

	public PruebaEjer2() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		
		DoublyLinkedList<Integer> lista1 = new DoublyLinkedList<Integer>();
		
		lista1.addLast(8);
		lista1.addLast(5);
		System.out.println("Prueba #1:\n");
    	System.out.print("Lista al derecho: ");
    	lista1.imprimirAlDerecho();
       	System.out.print("Lista al reves: ");
		lista1.imprimirAlReves();


		System.out.println("\nintercambiarConSig(8)\n");
		lista1.intercambiarConSig(8);
    	System.out.print("Lista al derecho: ");
    	lista1.imprimirAlDerecho();
       	System.out.print("Lista al reves: ");
		lista1.imprimirAlReves();
		
		System.out.println("\n==================================\nPrueba #2:\n");

		lista1.addLast(4);
		lista1.addLast(2);
		lista1.addLast(4);
		lista1.addLast(7);		
		lista1.addLast(6);
		
    	System.out.print("Lista al derecho: ");
    	lista1.imprimirAlDerecho();
       	System.out.print("Lista al reves: ");
		lista1.imprimirAlReves();

		System.out.println("\nintercambiarConSig(4)\n");
		lista1.intercambiarConSig(4);
    	System.out.print("Lista al derecho: ");
    	lista1.imprimirAlDerecho();
       	System.out.print("Lista al reves: ");
		lista1.imprimirAlReves();
		
		System.out.println("\n==================================\nPrueba #3:\n");
		
    	System.out.print("Lista al derecho: ");
    	lista1.imprimirAlDerecho();
       	System.out.print("Lista al reves: ");
		lista1.imprimirAlReves();

		System.out.println("\nintercambiarConSig(7)\n");
		lista1.intercambiarConSig(7);
    	System.out.print("Lista al derecho: ");
    	lista1.imprimirAlDerecho();
       	System.out.print("Lista al reves: ");
		lista1.imprimirAlReves();

		System.out.println("\n==================================\nPrueba #4:\n");

    	System.out.print("Lista al derecho: ");
    	lista1.imprimirAlDerecho();
       	System.out.print("Lista al reves: ");
		lista1.imprimirAlReves();

		System.out.println("\nintercambiarConSig(5)\n");
		lista1.intercambiarConSig(5);
    	System.out.print("Lista al derecho: ");
    	lista1.imprimirAlDerecho();
       	System.out.print("Lista al reves: ");
		lista1.imprimirAlReves();
	}
}