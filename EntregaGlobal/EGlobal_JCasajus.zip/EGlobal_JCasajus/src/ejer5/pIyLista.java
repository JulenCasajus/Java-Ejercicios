package ejer5;

import java.util.LinkedList;

public class pIyLista {

	int parInferiores;
	LinkedList<Integer> lista;
	
	public pIyLista(int pI, LinkedList<Integer> lista) {
		parInferiores = pI;
		this.lista = lista;
	}

	public int getParInferiores() {
		return parInferiores;
	}

	public void setParInferiores(int parInferiores) {
		this.parInferiores = parInferiores;
	}

	public LinkedList<Integer> getLista() {
		return lista;
	}

	public void setLista(LinkedList<Integer> lista) {
		this.lista = lista;
	}
}