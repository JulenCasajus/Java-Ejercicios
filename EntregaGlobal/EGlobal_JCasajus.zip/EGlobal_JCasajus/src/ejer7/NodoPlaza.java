package ejer7;

import java.util.LinkedList;

public class NodoPlaza {
	String nombre;
	int numCamaras;
	LinkedList<NodoPlaza> pAdyacentes;

	public NodoPlaza(String nombre, int numCamaras) {
		this.nombre = nombre;
		this.numCamaras = numCamaras;
		this.pAdyacentes = new LinkedList<NodoPlaza>();
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getNumCamaras() {
		return numCamaras;
	}

	public void setNumCamaras(int numCamaras) {
		this.numCamaras = numCamaras;
	}

	public LinkedList<NodoPlaza> getpAdyacentes() {
		return pAdyacentes;
	}

	public void setpAdyacentes(LinkedList<NodoPlaza> pAdyacentes) {
		this.pAdyacentes = pAdyacentes;
	}
}