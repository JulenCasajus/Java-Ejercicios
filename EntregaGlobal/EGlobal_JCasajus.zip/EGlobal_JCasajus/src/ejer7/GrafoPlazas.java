package ejer7;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

public class GrafoPlazas {
	private int numNodos; //numero de nodos del grafo
	private ArrayList<NodoPlaza> nodos; //nodos del grafo
		
	public GrafoPlazas() {
		this.numNodos = 0;
		this.nodos = new ArrayList<NodoPlaza>();
	}
	
    //pre: las plazas con nombre origen y destino estan en el grafo
    //pre: no hay camaras en origen y destino
    public int huida(NodoPlaza origen, NodoPlaza destino) {
    	
        Queue<NodoPlaza> cola = new LinkedList<>();
        cola.add(origen);
        boolean[] visitado = new boolean[numNodos];
        visitado[nodos.indexOf(origen)] = true;
        int longitudCamino = 0;

        while (!cola.isEmpty()) {
            for (int i = 0; i < cola.size(); i++) {
                NodoPlaza actual = cola.remove();
                if (actual.equals(destino)) return longitudCamino;
                for (NodoPlaza adyacente : actual.getpAdyacentes()) {
                    if (!visitado[nodos.indexOf(adyacente)] && adyacente.getNumCamaras() == 0) {
                        cola.add(adyacente);
                        visitado[nodos.indexOf(adyacente)] = true;
                    }
                }
            } 
            longitudCamino++;
        } 
        return -1;
    }
    
	///////// AUXILIARES PARA PRUEBAS (NO MODIFICAR) /////////
	
	public void anadirNodo(NodoPlaza nodo) {
		this.nodos.add(nodo);
		this.numNodos++;
	}
	
	public void anadirArista(NodoPlaza origen, NodoPlaza destino) {
		origen.pAdyacentes.add(destino);
		destino.pAdyacentes.add(origen);
	}
}