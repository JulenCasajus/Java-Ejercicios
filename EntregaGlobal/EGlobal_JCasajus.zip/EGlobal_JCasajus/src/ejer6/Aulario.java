package ejer6;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;

public class Aulario {

	public Aulario() {
		// TODO Auto-generated constructor stub
	}
	
	public HashMap<String, LinkedList<Reserva>> crearTablaReservas(ArrayList<Solicitud> solicitudes) {
		
		HashMap<String, LinkedList<Reserva>> hash = new HashMap<>();
		LinkedList<Reserva> lista;
		
		for(Solicitud solicitud : solicitudes) {
			
			String asignatura = solicitud.getAsignatura();
			String aula = solicitud.getAula();
			
			lista = hash.getOrDefault(aula, new LinkedList<Reserva>());
			
			if(lista.isEmpty()) lista.add(new Reserva(asignatura, 1, 'L', "9:00"));
			else {
				Reserva lastReserva = lista.get(lista.size() - 1);
				String hora = lastReserva.getHora();
				int semana = lastReserva.getSemana();
				char dia = lastReserva.getDiasemana();
				
				if(hora.equals("9:00")) lista.add(new Reserva(asignatura, semana, dia, "12:00"));
				else if(hora.equals("12:00")) lista.add(new Reserva(asignatura, semana, dia, "15:00"));
				else {
					if(dia == 'L') lista.add(new Reserva(asignatura, semana, 'M', "9:00"));
					else if(dia == 'M') lista.add(new Reserva(asignatura, semana, 'X', "9:00"));
					else if(dia == 'X') lista.add(new Reserva(asignatura, semana, 'J', "9:00"));
					else if(dia == 'J') lista.add(new Reserva(asignatura, semana, 'V', "9:00"));
					else if(dia == 'V') lista.add(new Reserva(asignatura, semana + 1, 'L', "9:00"));
				}
			}
			hash.put(aula, lista);	
		}
		return hash;
	}
}