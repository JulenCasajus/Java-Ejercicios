package ejer6;

public class Solicitud {
	
	private String asignatura;
	private String aula;

	public Solicitud(String asignatura, String aula) {
		this.asignatura = asignatura;
		this.aula = aula;
	}
	
	public String getAsignatura() {
		return asignatura;
	}

	public String getAula() {
		return aula;
	}
}