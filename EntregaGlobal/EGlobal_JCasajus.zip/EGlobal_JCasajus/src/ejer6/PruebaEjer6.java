package ejer6;

import java.util.ArrayList;

public class PruebaEjer6 {

	public PruebaEjer6() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		
		ArrayList<Solicitud> solicitudes = new ArrayList<Solicitud>();
		solicitudes.add(new Solicitud("PB", "2.6"));
		solicitudes.add(new Solicitud("PDSD", "1.2"));
		solicitudes.add(new Solicitud("FTC", "2.6"));
		solicitudes.add(new Solicitud("MD", "2.6"));
		solicitudes.add(new Solicitud("AM", "3.16"));
		solicitudes.add(new Solicitud("EC", "2.6"));
		solicitudes.add(new Solicitud("ALG", "2.6"));
		solicitudes.add(new Solicitud("CAL", "1.2"));
		solicitudes.add(new Solicitud("PMOO", "2.6"));
		solicitudes.add(new Solicitud("MP", "2.6"));
		solicitudes.add(new Solicitud("EAE", "2.6"));
		solicitudes.add(new Solicitud("MEI", "2.6"));
		solicitudes.add(new Solicitud("AC", "2.6"));
		solicitudes.add(new Solicitud("LCSI", "2.6"));
		solicitudes.add(new Solicitud("IS1", "2.6"));
		solicitudes.add(new Solicitud("BD", "1.2"));
		solicitudes.add(new Solicitud("IO", "2.6"));
		solicitudes.add(new Solicitud("ISO", "2.6"));
		solicitudes.add(new Solicitud("IRC", "2.6"));
		solicitudes.add(new Solicitud("SAR", "3.16"));
		solicitudes.add(new Solicitud("CC", "2.6"));
		solicitudes.add(new Solicitud("MAC", "1.2"));
		
		Aulario aulario = new Aulario();
		System.out.println(aulario.crearTablaReservas(solicitudes));
	}
}