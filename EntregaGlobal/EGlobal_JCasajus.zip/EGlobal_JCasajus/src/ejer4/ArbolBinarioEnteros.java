package ejer4;

public class ArbolBinarioEnteros {
	
	NodoEnteros root;

	public ArbolBinarioEnteros() {	
	}
	
	public boolean isEmpty() {
		return (root == null);
	}

	public void imprimirArbol() {
		if (this.isEmpty()) System.out.println("*");
		else {
			this.root.imprimirArbol();
			System.out.println();
		}
	}
	
	public void modificarNodo() {
		if(!isEmpty()) root.modificarNodo();
	}
}