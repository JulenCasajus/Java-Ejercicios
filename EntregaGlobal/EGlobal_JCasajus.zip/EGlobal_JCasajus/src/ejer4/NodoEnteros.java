package ejer4;

public class NodoEnteros {

	int info;
	NodoEnteros left;
	NodoEnteros right;

	public NodoEnteros(int info) {
		this.info = info;
	}

	// Devuelve si el nodo es hoja
	public boolean isLeaf() {
		return (left == null && right == null);
	}

	// Devuelve si el nodo tiene subarbol izquierdo
	public boolean hasLeft() {
		return (left != null);
	}

	// Devuelve si el nodo tiene subarbol derecho
	public boolean hasRight() {
		return (right != null);
	}
	
	public void imprimirArbol() {
		if(this.isLeaf()) System.out.print("[ " + info + " ] ");
		else {
			System.out.print("[ " + info + " ");
			if(hasLeft()) left.imprimirArbol();
			else System.out.print("* ");
			if(hasRight()) right.imprimirArbol();
			else System.out.print("* ");
			System.out.print("] ");
		}		
	}
	
	public int modificarNodo() {
		
		int izq = 0, der = 0;
		
		if(hasLeft()) izq = left.modificarNodo();
		if(hasRight()) der = right.modificarNodo();
		
		if(info > izq && info > der) {
			info += info;
			return info/2;
		}
		if(izq > der) {
			info += izq;
			return izq;
		}
		info += der;
		return der;
	}
}