package ejer3;

public class Ejer3 {

	//Devuelve si texto es palindromo, teniendo en cuenta los espacios en blanco.
	//Pre: texto esta en minuscula
	public static boolean esPalindromo_v1(char[] texto) {
				return esPalindromo_v1(texto, 0, texto.length-1);
	}
	
	public static boolean esPalindromo_v1(char[] texto, int ini, int fin) {
		if(ini < fin) {
			if(texto[ini] == texto[fin]) {
				return esPalindromo_v1(texto, ini + 1, fin - 1);
			} else return false;
		} return true;
	}

	//Devuelve si texto es palindromo, sin tener en cuenta los espacios en blanco.
	//Pre: texto esta en minuscula
	public static boolean esPalindromo_v2(char[] texto) {
		return esPalindromo_v2(texto, 0, texto.length - 1);
	}
	
	public static boolean esPalindromo_v2(char[] texto, int ini, int fin) {
		if(ini < fin) {
			while(texto[ini] == ' ') ini++;
			while(texto[fin] == ' ') fin--;
			if(texto[ini] == texto[fin]) {
				return esPalindromo_v2(texto, ini + 1, fin - 1);
			} else return false;
		} return true;
	}	
}