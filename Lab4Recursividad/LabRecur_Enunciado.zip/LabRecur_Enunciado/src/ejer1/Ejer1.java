package ejer1;

public class Ejer1 {

	//Pre: n>0
	public static int sumatorio(int n) {
		//TO DO
		return -1; //corregir si necesario
	}

}
