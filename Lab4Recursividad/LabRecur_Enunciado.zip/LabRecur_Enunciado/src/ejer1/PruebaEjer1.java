package ejer1;

public class PruebaEjer1 {


	public static void main(String[] args) {

        System.out.println(Ejer1.sumatorio(1)); //1
        System.out.println(Ejer1.sumatorio(5)); //15
        System.out.println(Ejer1.sumatorio(10));//55

	}

}
