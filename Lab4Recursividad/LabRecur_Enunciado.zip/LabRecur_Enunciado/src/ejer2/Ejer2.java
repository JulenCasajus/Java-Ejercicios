package ejer2;

public class Ejer2 {

	//pre: n>=0
	public static String decimalABinario(int n) {
		
		//TO DO
		return null; //corregir si necesario
	}

}
