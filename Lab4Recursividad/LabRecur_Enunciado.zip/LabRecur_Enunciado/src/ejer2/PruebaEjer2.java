package ejer2;

public class PruebaEjer2 {

	public PruebaEjer2() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		
		for(int i=0; i<32; i++) {
			System.out.println(i+": "+Ejer2.decimalABinario(i));
		}
		
		System.out.println("100: "+Ejer2.decimalABinario(100));

	}

}
