package ejer3;

public class PruebaEjer3 {

	public static void main(String[] args) {

      String texto = "murder for a jar of red rum";
      System.out.println(texto);      
      System.out.println("v1: "+Ejer3.esPalindromo_v1(texto.toCharArray())); //false
      System.out.println("v2: "+Ejer3.esPalindromo_v2(texto.toCharArray())); //true
      
      
      texto = "step on no pets";
      System.out.println("\n"+texto);      
      System.out.println("v1: "+Ejer3.esPalindromo_v1(texto.toCharArray())); //true
      System.out.println("v2: "+Ejer3.esPalindromo_v2(texto.toCharArray())); //true
      
      
      texto = "no lemon no melon";
      System.out.println("\n"+texto);      
      System.out.println("v1: "+Ejer3.esPalindromo_v1(texto.toCharArray())); //false
      System.out.println("v2: "+Ejer3.esPalindromo_v2(texto.toCharArray())); //true 
      
      texto = "never odd and even";
      System.out.println("\n"+texto);      
      System.out.println("v1: "+Ejer3.esPalindromo_v1(texto.toCharArray())); //false
      System.out.println("v2: "+Ejer3.esPalindromo_v2(texto.toCharArray())); //false 
      
	}

}
