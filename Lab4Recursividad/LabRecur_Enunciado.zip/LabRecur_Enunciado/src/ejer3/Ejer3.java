package ejer3;

public class Ejer3 {

	//Devuelve si texto es palíndromo, teniendo en cuenta los espacios en blanco.
	//Pre: texto está en minúscula
	public static boolean esPalindromo_v1(char[] texto) {
		//TO DO
		return false; //corregir si necesario
	}
	

	
	//Devuelve si texto es palíndromo, sin tener en cuenta los espacios en blanco.
	//Pre: texto está en minúscula
	public static boolean esPalindromo_v2(char[] texto) {
		//TO DO
		return false; //corregir si necesario
	}
	


}
