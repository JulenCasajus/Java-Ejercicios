package ejer2;

public class RegistroMariposas {

	
	//Estados: 'H' (huevo), 'O' (oruga), 'C': cris�lida, 'M': mariposa adulta
	public int primeraCrisalida(char[] registroEstados) {
	    int medio, izquierda = 0, derecha = registroEstados.length - 1;
	    int primeraCrisalida = -1;
	    
	    while (izquierda <= derecha) {
	        medio = (izquierda + derecha) / 2;

	        if (registroEstados[medio] == 'C' || registroEstados[medio] == 'M') {
	            primeraCrisalida = medio;
	            derecha = medio - 1; // Buscar en la mitad izquierda
	        } else {
	            izquierda = medio + 1; // Buscar en la mitad derecha
	        }
	    }

	    return primeraCrisalida;
	}

}