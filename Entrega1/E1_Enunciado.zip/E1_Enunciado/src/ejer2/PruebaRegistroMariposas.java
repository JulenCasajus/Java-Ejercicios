package ejer2;

public class PruebaRegistroMariposas {

	public PruebaRegistroMariposas() {
		// TODO Auto-generated constructor stub
	}
	
	

	public static void main(String[] args) {
		
		String[] casosDePrueba = { "CCMMMM", 
				                   "HHHOOOOCCMM"
		}; //completar con m�s casos de prueba
		
		char[] registro = null;
		RegistroMariposas rm;
		
		for(String s:casosDePrueba) {
			registro = s.toCharArray();
			rm = new RegistroMariposas();
			int primera = rm.primeraCrisalida(registro);
			System.out.print(s+": ");
			if(primera!=-1) System.out.println("La primera cris�lida se ha observado en la visita "+primera+".");
			else System.out.println("No se han observado cris�lidas.");	
		}
		
		
	
	}

}
