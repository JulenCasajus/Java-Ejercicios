package ejer2;

public class RegistroMariposas {

	
	//Estados: 'H' (huevo), 'O' (oruga), 'C': cris�lida, 'M': mariposa adulta
	public int primeraCrisalida(char[] registroEstados) {
		
		
		//TO DO
			
		return -1; //corregir si necesario
		
	}

}
