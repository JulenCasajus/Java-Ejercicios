package ejer1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Random;
import java.util.Scanner;

public class RegistroTemperaturas {
	
	private float temp[][];

	public RegistroTemperaturas(String nomFich) {
		try {
			System.out.println("Cargando fichero original...");
			cargarTemperaturasFich(nomFich);
			imprimir();
		}catch(FileNotFoundException e) {
			System.out.println("Fichero no disponible.");
		}
		
	}
	
	
	/**
	 * pre: temp est� cargado y tiene al menos dos filas y dos columnas
	 * post: se ha actualizado temp sumando var a los registros de la ciudad x y actualizando los totales
	 * @param x: �ndice de la ciudad a actualizar. Es v�lido.
	 * @param var: valor que hay que sumar a los registros de la ciudad x
	 */
	public void actualizar1(int x, float var) {
		
		//actualizar valores de temperatura
		for(int j=0; j<temp[x].length-1; j++) {
			temp[x][j]+=var;
		}
		
		//actualizar total negativos de cada ciudad
		for(int i=0; i<temp.length-1; i++) {
			int negativos = 0;
			for(int j=0; j<temp[i].length-1; j++) {
				if(temp[i][j]<0) negativos++;
			}
			temp[i][temp[i].length-1] = negativos;
		}
		
		//actualizar total negativos de cada d�a
		for(int j=0; j<temp[0].length-1; j++) {
			int negativos = 0;
			for(int i=0; i<temp.length-1; i++) {
				if(temp[i][j]<0) negativos++;
			}
			temp[temp.length-1][j] = negativos;
		}

	}
	
	
	/**
	 * pre: temp est� cargado y tiene al menos dos filas y dos columnas
	 * post: se ha actualizado temp sumando var a los registros de la ciudad x y actualizando los totales
	 * @param x: �ndice de la ciudad a actualizar. Es v�lido.
	 * @param var: valor que hay que sumar a los registros de la ciudad x
	 */
	public void actualizar2(int x, float var) {
		
		//TO DO

	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/**
	 * M�TODOS AUXILIARES PARA PRUEBAS (NO MODIFICAR)
	 */
	public void imprimir() {
		System.out.println("Contenido de la matriz:");
		for(int i=0; i<temp.length; i++) {		
			for(int j=0; j<temp[i].length; j++) {
				System.out.printf("%.1f\t", temp[i][j]);
			}
			System.out.println();
		}
		System.out.println();
	}
	
	public void cargarTemperaturasFich(String nomFich) throws FileNotFoundException  {
		Scanner source = new Scanner(new File(nomFich));

		int numFilas = Integer.parseInt(source.nextLine());
		int numCols  = Integer.parseInt(source.nextLine());		
		
		temp = new float[numFilas][numCols];
		
		String linea;
		String[] s;
		int i = 0;
		while(source.hasNext()) {
			linea = source.nextLine();
			s = linea.split("\\s+");
			for(int j=0; j<s.length; j++) {
				temp[i][j] = Float.parseFloat(s[j]);
			}
			i++;
		}
		source.close();
	}
	

	

}
