package ejer1;

public class PruebaRegistroTemperaturas {

	public PruebaRegistroTemperaturas() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		RegistroTemperaturas rt = new RegistroTemperaturas("src/files/temp01");
		System.out.println("Actualizando registro...");
		rt.actualizar2(2, 3);
		rt.imprimir();
	}

}
