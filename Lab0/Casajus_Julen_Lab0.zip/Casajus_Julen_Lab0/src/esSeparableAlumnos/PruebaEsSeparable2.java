package esSeparableAlumnos;

import java.util.Arrays;

import auxiliares.ArrayCreator;
import auxiliares.Stopwatch;

public class PruebaEsSeparable2 {

    public static void main(String[] args) { 
    	
    	Separable sepa = new Separable();
    	
    	System.out.println("---------------------------");
    	System.out.println("Pruebas de funcionamiento: ");
    	System.out.println("---------------------------");
    	
    	Integer[] a1 = {3, 4, 2, 6, 3, 5, 1, 3, 2, 1};
    	System.out.println(Arrays.toString(a1) + ": " + sepa.esSeparable2(a1)); //true
    	
    	
    	Integer[] a2 = {1, 2, 2, 4, 5};
    	System.out.println(Arrays.toString(a2) + ": " + sepa.esSeparable2(a2)); //false 
    	
    	Integer[] a3 = {5, 1, 5, 1, 1, 13};
    	System.out.println(Arrays.toString(a3) + ": " + sepa.esSeparable2(a3)); //true
    	
    	
    	Integer[] a4 = {6, 1, 5, 11};
    	System.out.println(Arrays.toString(a4) + ": " + sepa.esSeparable2(a4)); //false 
    	
    	
    	System.out.println("---------------------------");
    	System.out.println("Pruebas de eficiencia: ");
    	System.out.println("---------------------------");  
    	
    	Stopwatch timer;    	
    	int N = 250;
    	Integer[] a;
    	
        while(true)	{        	
        	a = ArrayCreator.createArray(N); //Crea un array de N enteros, de manera aleatoria
        	timer = new Stopwatch(); //Pone en marcha el cronometro
        	sepa.esSeparable2(a);            
            System.out.println(N + ": " + timer.elapsedTime());  //Imprime el tiempo transcurrido
            N = 2 * N; //Duplicamos el numero de elementos del array
        } 
    } 
}
