package arbolBinarioAlumnos;

public class ResultadoContainsYNivel {

	boolean contains;
	int nivel;
	
	public ResultadoContainsYNivel() {}
	
	public ResultadoContainsYNivel(boolean contains, int nivel) {
		this.contains = contains;
		this.nivel = nivel;
	}

	

}
