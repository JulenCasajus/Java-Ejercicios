package arbolBinarioAlumnos;

import java.util.LinkedList;

public class Nodo<T> {

	T info;
	Nodo<T> left;
	Nodo<T> right;

	// Metodos basicos

	public Nodo(T info) {
		this.info = info;
	}

	// Devuelve si el nodo es hoja
	public boolean isLeaf() {
		return (left == null && right == null);
	}

	// Devuelve si el nodo tiene subarbol izquierdo
	public boolean hasLeft() {
		return (left != null);
	}

	// Devuelve si el nodo tiene subarbol derecho
	public boolean hasRight() {
		return (right != null);
	}

	// EJERCICIO 1
	public LinkedList<T> elementosEnInOrden() {
		LinkedList<T> Lista = new LinkedList<T>();
		if(hasLeft()) Lista.addAll(left.elementosEnInOrden());
		Lista.addLast(info);
		if(hasRight()) Lista.addAll(right.elementosEnInOrden());
		return Lista;
	}

	// EJERCICIO 2
	public ResultadoContainsYNivel containsYNivel(T elem, int nivel) {
		if(equals(elem)) return new ResultadoContainsYNivel(true, nivel);
		if(hasRight()) {
			ResultadoContainsYNivel resD = right.containsYNivel(elem, nivel + 1);
			if(resD.contains == true) return resD;
		} if(hasLeft()) {
			ResultadoContainsYNivel resI = left.containsYNivel(elem, nivel + 1);
			if(resI.contains == true) return resI;
		}
		return new ResultadoContainsYNivel(false, -1);
	}

	// EJERCICIO 3
	public int altura() {
		int izq = 0, der = 0;
		if(hasRight()) der = 1 + right.altura();
		if(hasLeft()) izq = 1 + left.altura();
		return Math.max(izq, der);
	}

	// EJERCICIO 4
	public LinkedList<T> obtenerCaminoHojaIzquierda() {
		LinkedList<T> Lista = new LinkedList<T>();
		if(hasLeft()) Lista.addAll(left.obtenerCaminoHojaIzquierda());
		else if(hasRight()) Lista.addAll(right.obtenerCaminoHojaIzquierda());
		Lista.addFirst(info);
		return Lista;
	}
}