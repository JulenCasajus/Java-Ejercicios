package arbolBinarioAlumnos;

import java.util.LinkedList;

public class ArbolBinario<T extends Comparable<T>> {

	Nodo<T> root;

	//Metodos basicos

	public ArbolBinario() {
		this.root = null;
	}

	public ArbolBinario(T info) {
		this.root = new Nodo<T>(info);
	}

	public ArbolBinario(Nodo<T> root) {
		this.root = root;
	}

	public boolean isEmpty() {
		return (root == null);
	}

	//EJERCICIO 1
	//Devuelve la lista de elementos en inorden (lista vacia si no tiene elementos)	
	public LinkedList<T> elementosEnInOrden(){
		if(!isEmpty()) return root.elementosEnInOrden();
		else return new LinkedList<T>();
	}

	//EJERCICIO 2
	//Devuelve si el elemento esta en el arbol y en que nivel (-1 si no esta, cualquiera de los niveles en que este si esta repetido)	
	public ResultadoContainsYNivel containsYNivel(T elem) {
		if(!isEmpty()) return root.containsYNivel(elem, 0);
		return new ResultadoContainsYNivel(false, -1);
	}	

	//EJERCICIO 3
	//Devuelve la altura del arbol (-1 si no tiene elementos)	
	public int altura() {
		if(!isEmpty()) return root.altura();
		return -1;
	}
	
	//EJERCICIO 4
	//Devuelve una lista con el camino desde la raiz hasta la hoja situada mas a la izquierda (lista vacia si no tiene elementos)
	public LinkedList<T> obtenerCaminoHojaIzquierda(){
		if(!isEmpty()) return root.obtenerCaminoHojaIzquierda();
		else return new LinkedList<T>();
	}
}