package ejer1;


public class PruebaParking {

	public PruebaParking() {
		
	}

	public static void main(String[] args) {
		//TO DO: DESCOMENTAR Y COMPLETAR SUSTITUYENDO LAS XXXXX POR LOS TIPOS Y M�TODOS ADECUADOS
		/*
		XXXXX eventos = new XXXXX();
		eventos.XXXXX(new Evento('E',"1212ABS",null));
		eventos.XXXXX(new Evento('E',"3412GHT",null));
		eventos.XXXXX(new Evento('E',"7564ODE",null));
		eventos.XXXXX(new Evento('E',"9876YYY",null));
		eventos.XXXXX(new Evento('S',null,2));
		eventos.XXXXX(new Evento('E',"5902BHE",null));
		eventos.XXXXX(new Evento('S',null,2));
		eventos.XXXXX(new Evento('S',null,1));
		eventos.XXXXX(new Evento('E',"6112DEX",null));
		eventos.XXXXX(new Evento('E',"7456MKS",null));
		eventos.XXXXX(new Evento('E',"9999ABC",null));
		
		Parking p = new Parking();
		p.simularEventos(eventos);
		*/

	}

}
