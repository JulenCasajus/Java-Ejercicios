package ejer1;


public class Parking { 
	private final int TOTALPLAZAS = 50;
      //private XXXXX plazas;	// TO DO: DESCOMENTAR ESTA LINEA Y COMPLETAR SUSTITUYENDO LAS XXXXX POR EL TIPO ADECUADO
	  //private XXXXX ticketsARepartir;	// TO DO: DESCOMENTAR ESTA LINEA Y COMPLETAR SUSTITUYENDO LAS XXXXX POR EL TIPO ADECUADO	
	
	  public Parking() {
		  
		    //TO DO  
	  }
	 
	public void simularEventos(/*XXXX eventos*/){ //TO DO: DESCOMENTAR PAR�METRO DE ENTRADA Y COMPLETAR SUSTITUYENDO LAS XXXXX POR EL TIPO ADECUADO
		
		//TO DO  
      }
	
}