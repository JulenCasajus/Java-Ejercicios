package ejer1;

public class Ticket {
	 private int numPlaza;

	public Ticket(int numPlaza) { 
		 this.numPlaza =  numPlaza;
	}
	public int getNumPlaza() {
		return numPlaza;
	}
	
	 public void setNumPlaza(int numPlaza) {
		this.numPlaza = numPlaza;
	}
}