package ejer1;


public class Plaza {  	
	//private XXXXX registroMatriculas; // TO DO: DESCOMENTAR ESTA LINEA Y COMPLETAR SUSTITUYENDO LAS XXXXX POR EL TIPO ADECUADO
	
	public Plaza() {
		    //TO DO
	}
	


	// Registra la matr�cula en el registro de matr�culas de esta plaza
	public void registrarCoche(String matricula) {
			//TO DO
	}
	
}
