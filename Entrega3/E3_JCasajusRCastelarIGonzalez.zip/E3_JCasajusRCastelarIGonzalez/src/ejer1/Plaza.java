package ejer1;

import java.util.LinkedList;
import java.util.Queue;

public class Plaza {
	
	private Queue<String> registroMatriculas;
	
	public Plaza() {
		registroMatriculas = new LinkedList<String>();
	}

	// Registra la matricula en el registro de matriculas de esta plaza
	public void registrarCoche(String matricula) {
		registroMatriculas.add(matricula);
	}
	
	public boolean isEmpty() {
		return registroMatriculas.isEmpty();
	}
	
	public String remove() {
		return registroMatriculas.remove();
	}
}