package ejer1;

import java.util.LinkedList;
import java.util.Queue;

public class Parking { 
	private final int TOTALPLAZAS = 50;
    private Plaza[] plazas;
    private int[] ocupada = new int[TOTALPLAZAS]; //indica si una plaza esta libre u ocupada
	private Queue<Ticket> ticketsARepartir;

	public Parking() {
		plazas = new Plaza[TOTALPLAZAS]; 
		for(int i = 0; i < TOTALPLAZAS; i++) {
			plazas[i] = new Plaza();
		}
		ticketsARepartir = new LinkedList<Ticket>();
	}

	public void simularEventos(LinkedList<Evento> eventos) {
		
		System.out.println(" - - Simulacion de eventos - -\n");
		
		while(!eventos.isEmpty()) {
			if(eventos.element().getTipo() == 'E') {
				int i = 0;
				while(i < TOTALPLAZAS - 1 && ocupada[i] != 0) {
					i++;
				}
				if(ocupada[i] == 0) {
					plazas[i].registrarCoche(eventos.element().getMatric());
					ocupada[i] = 1;
					System.out.println("El coche " + eventos.element().getMatric() + " va a la plaza " + i);
				} else System.out.println("El parking esta lleno");
				
			} else if(eventos.element().getTipo() == 'S') {
				ticketsARepartir.add(new Ticket(eventos.element().getNumPlaza()));
				ocupada[eventos.element().getNumPlaza()] = 0;
				System.out.println("Se ha liberado la plaza " + eventos.element().getNumPlaza());
			}
			eventos.remove();
		}
		
		System.out.println("\n - - Registro de matriculas - -");
		
		int j = 0;
		while(!plazas[j].isEmpty()) {
			System.out.print("\nPlaza " + j + ": ");
			while(!plazas[j].isEmpty()) {
				System.out.print(plazas[j].remove() + " ");
			} j++;
		}
    }
}