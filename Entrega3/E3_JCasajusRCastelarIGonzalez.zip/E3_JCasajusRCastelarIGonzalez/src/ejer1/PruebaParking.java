package ejer1;

import java.util.LinkedList;

public class PruebaParking {

	public PruebaParking() {
		
	}

	public static void main(String[] args) {

		LinkedList<Evento> eventos = new LinkedList<Evento>();
		eventos.add(new Evento('E',"1212ABS",null));
		eventos.add(new Evento('E',"3412GHT",null));
		eventos.add(new Evento('E',"7564ODE",null));
		eventos.add(new Evento('E',"9876YYY",null));
		eventos.add(new Evento('S',null,2));
		eventos.add(new Evento('E',"5902BHE",null));
		eventos.add(new Evento('S',null,2));
		eventos.add(new Evento('S',null,1));
		eventos.add(new Evento('E',"6112DEX",null));
		eventos.add(new Evento('E',"7456MKS",null));
		eventos.add(new Evento('E',"9999ABC",null));
		
		Parking p = new Parking();
		p.simularEventos(eventos);
	}
}
