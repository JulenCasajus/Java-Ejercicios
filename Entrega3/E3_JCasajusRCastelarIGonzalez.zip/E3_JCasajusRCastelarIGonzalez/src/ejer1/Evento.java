package ejer1;

public class Evento { //suponemos getters y setters
    private Character tipo; // 'E' entrada, 'S' salida
	private String matric; // Matricula coche (solo si tipo = E, si no, null)
    private Integer numplaza;//Plaza que se vacia(solo si tipo = S,si no, null)

	public Evento(Character tipo, String matric, Integer numplaza) {
		this.tipo = tipo;
		this.matric = matric;
		this.numplaza = numplaza;	
	}

	public Character getTipo() {
		return tipo;
	}

	public String getMatric() {
		return matric;
	}

	public int getNumPlaza() {
		return numplaza;
	}

    public void setTipo(Character tipo) {
		this.tipo = tipo;
	}

	public void setMatric(String matric) {
		this.matric = matric;
	}

	public void setNumPlaza(Integer numplaza) {
		this.numplaza = numplaza;
	}
}