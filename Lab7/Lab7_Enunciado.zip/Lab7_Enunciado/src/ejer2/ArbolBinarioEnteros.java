package ejer2;

import java.util.LinkedList;

public class ArbolBinarioEnteros {
	
	NodoEnteros root;

	public ArbolBinarioEnteros() {
		
	}
	
	public boolean isEmpty() {
		return (root == null);
	}
	

	public void imprimirArbol() {
		if (this.isEmpty())
			System.out.println("*");
		else {
			this.root.imprimirArbol();
			System.out.println();
		}

	}
	
	public LinkedList<Integer> caminoMasPesado(){
		//TO DO
		return null; //CORREGIR SI NECESARIO
	}
	


}
