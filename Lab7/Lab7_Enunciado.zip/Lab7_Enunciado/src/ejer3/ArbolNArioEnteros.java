package ejer3;

public class ArbolNArioEnteros {

	NodoNArioEnteros root;
	int grado;

	public ArbolNArioEnteros(int grado) {
		this.root = null;
		this.grado = grado;
	}
	
	public boolean isEmpty() {
		return (root == null);
	}
	
	public int difMenorMayor() {
		//TO DO
		return -1; //CORREGIR SI NECESARIO
	}

}
