package ejer3;

public class NodoNArioEnteros {

	int info;
	NodoNArioEnteros[] hijos;

	public NodoNArioEnteros(int info, int grado) {
		this.info = info;
		this.hijos = new NodoNArioEnteros[grado];
	}

	public boolean isLeaf() {// Devuelve si el nodo es hoja o no
		for (int i = 0; i < this.hijos.length; i++) {
			if (this.hijos[i] != null)
				return false;
		}
		return true;
	}

	public boolean hasIthChild(int i) {// Devuelve si el nodo tiene i�simo hijo o no
		return this.hijos[i] != null;
	}
	
	//difMenorMayor()
	   //TO DO

}
