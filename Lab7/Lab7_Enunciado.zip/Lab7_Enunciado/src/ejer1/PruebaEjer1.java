package ejer1;

import java.io.File;
import java.util.Scanner;




public class PruebaEjer1 {

	//C�DIGO PARA LA CARGA DE LOS EJEMPLOS DE PRUEBA, NO MODIFICAR
	
		public static ABBEnteros cargar(String nomFich) throws Exception {
			ABBEnteros result = new ABBEnteros();
			Scanner source = new Scanner(new File(nomFich));
			String token = source.next();
			if (token.equals("*"))
				result.root = null;
			else if (token.equals("["))
				result.root = cargar(source);
			else
				throw new Exception(String.format("Unexpected token when reading " + "binary tree: %s", token));
			return result;
		}

		public static NodoABBEnteros cargar(Scanner source) throws Exception{
			NodoABBEnteros result = new NodoABBEnteros(source.nextInt());
			String token = source.next();
			if (token.equals("]")) {
				result.left = null;
				result.right = null;
			} else {
				if (token.equals("["))
					result.left = cargar(source);
				else if (token.equals("*"))
					result.left = null;
				else
					throw new Exception(String.format("Unexpected token when " + "reading binary tree: %s", token));
				token = source.next();
				if (token.equals("["))
					result.right = cargar(source);
				else if (token.equals("*"))
					result.right = null;
				else
					throw new Exception(String.format("Unexpected token when " + "reading binary tree: %s", token));
				token = source.next();
				if (!token.equals("]"))
					throw new Exception(String.format("Unexpected token when " + "reading binary tree: %s", token));
			}
			return result;
		}

	public static void main(String[] args) throws Exception {
		
        ABBEnteros ab;
		
		for(int i=0; i<=5; i++) {
			
			System.out.println("\n-------------\n �RBOL "+i+"\n-------------");
			ab = cargar("src/filesABB/arbolABB"+i+".txt");
			
			System.out.println("\n�rbol original: ");
			ab.imprimirArbol();
			System.out.println("Tras eliminar hojas menores que 16: ");
			ab.borrarHojasMenoresQue(16);
			ab.imprimirArbol();
			
			ab = cargar("src/filesABB/arbolABB"+i+".txt");
			
			System.out.println("\n�rbol original: ");
			ab.imprimirArbol();
			System.out.println("Tras eliminar hojas menores que 50: ");
			ab.borrarHojasMenoresQue(50);
			ab.imprimirArbol();
			
			ab = cargar("src/filesABB/arbolABB"+i+".txt");
			
			System.out.println("\n�rbol original: ");
			ab.imprimirArbol();
			System.out.println("Tras eliminar hojas menores que 4: ");
			ab.borrarHojasMenoresQue(4);
			ab.imprimirArbol();
			
	
			
		}

	}

}
