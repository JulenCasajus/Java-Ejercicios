package ejer1;

import java.util.LinkedList;

public class ABBEnteros {
	
	NodoABBEnteros root;

	public ABBEnteros() {
		
	}
	
	public boolean isEmpty() {
		return (root == null);
	}
	

	public void imprimirArbol() {
		if (this.isEmpty())
			System.out.println("*");
		else {
			this.root.imprimirArbol();
			System.out.println();
		}

	}
	
	public void borrarHojasMenoresQue(int num) {
		//TO DO
	}
	


}
