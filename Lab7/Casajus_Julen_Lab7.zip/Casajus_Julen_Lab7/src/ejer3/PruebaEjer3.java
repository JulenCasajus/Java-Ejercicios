package ejer3;

import java.io.File;
import java.util.Scanner;

public class PruebaEjer3 {

	public PruebaEjer3() {
		// TODO Auto-generated constructor stub
	}

	// CODIGO PARA LA CARGA DE LOS EJEMPLOS DE PRUEBA, NO MODIFICAR

	public static ArbolNArioEnteros cargar(String nomFich, int grado) throws Exception {
		ArbolNArioEnteros result = new ArbolNArioEnteros(grado);
		Scanner source = new Scanner(new File(nomFich));
		String token = source.next();
		if (token.equals("*")) result.root = null;
		else if (token.equals("[")) result.root = cargar(source, grado);
		else throw new Exception(String.format("Unexpected token when reading " + "binary tree: %s", token));
		return result;
	}

	public static NodoNArioEnteros cargar(Scanner source, int grado) throws Exception {
		int next = source.nextInt();
		NodoNArioEnteros result = new NodoNArioEnteros(next, grado);
		String token = source.next();
		if (token.equals("]")) {
			for (int i = 0; i < grado; i++) {
				result.hijos[i] = null;
			}
		} else {
			for (int i = 0; i < grado; i++) {
				if (token.equals("[")) result.hijos[i] = cargar(source, grado);
				else if (token.equals("*")) result.hijos[i] = null;
				else throw new Exception(String.format("Unexpected token when " + "reading N-ary tree 1: %s", token));
				// if(i<grado-1) {
				token = source.next();
				// }
			}
			// if (!token.equals("]"))
			// throw new Exception(String.format("Unexpected token when " + "reading N-ary
			// tree 2: %s", token));
		}
		return result;
	}

	// FIN DEL CODIGO PARA LA CARGA DE LOS EJEMPLOS DE PRUEBA

	public static void main(String[] args) throws Exception {

		ArbolNArioEnteros ab;
		int grado = 4;

		for (int i = 0; i <= 3; i++) {
			System.out.println("\n-------------\n ARBOL " + i + "\n-------------");
			ab = cargar("src/filesNArios/arbolNArio" + i + ".txt", grado);
			
			System.out.println(ab.difMenorMayor());
		}
	}
}