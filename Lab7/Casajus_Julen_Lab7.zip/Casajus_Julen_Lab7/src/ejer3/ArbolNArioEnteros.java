package ejer3;

public class ArbolNArioEnteros {

	NodoNArioEnteros root;
	int grado;

	public ArbolNArioEnteros(int grado) {
		this.root = null;
		this.grado = grado;
	}
	
	public boolean isEmpty() {
		return (root == null);
	}
	
	public int difMenorMayor() {
		if(isEmpty()) return 0;
		MinMax MM = root.difMenorMayor();
		return MM.max - MM.min;
	}
}