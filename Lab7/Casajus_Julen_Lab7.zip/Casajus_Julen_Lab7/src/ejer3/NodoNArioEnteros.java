package ejer3;

public class NodoNArioEnteros {

	int info;
	NodoNArioEnteros[] hijos;

	public NodoNArioEnteros(int info, int grado) {
		this.info = info;
		this.hijos = new NodoNArioEnteros[grado];
	}

	// Devuelve si el nodo es hoja o no
	public boolean isLeaf() {
		for (int i = 0; i < hijos.length; i++) {
			if (hijos[i] != null)
				return false;
		}
		return true;
	}

	// Devuelve si el nodo tiene i-esimo hijo o no
	public boolean hasIthChild(int i) {
		return hijos[i] != null;
	}
	
	public MinMax difMenorMayor() {
		MinMax MM = new MinMax(info, info);
		for (int i = 0; i < hijos.length; i++) {
			if(hasIthChild(i)) {
				MinMax Aux = hijos[i].difMenorMayor();
				MM.max = Math.max(Aux.max, MM.max);	
				MM.min = Math.min(Aux.min, MM.min);
			}
		}
		return MM;
	}
}