package ejer2;

import java.util.LinkedList;;

public class ListaYPeso {

	LinkedList<Integer> lista;
	int peso;
	
	public ListaYPeso(LinkedList<Integer> lista, int peso) {
		this.lista = lista;
		this.peso = peso;
	}

	public LinkedList<Integer> getLista() {
		return lista;
	}

	public void setLista(LinkedList<Integer> lista) {
		this.lista = lista;
	}

	public int getPeso() {
		return peso;
	}

	public void setPeso(int peso) {
		this.peso = peso;
	}
}