package ejer1;

public class NodoABBEnteros {

	int info;
	NodoABBEnteros left;
	NodoABBEnteros right;

	public NodoABBEnteros(int info) {
		this.info = info;
	}

	// Devuelve si el nodo es hoja
	public boolean isLeaf() {
		return (left == null && right == null);
	}

	// Devuelve si el nodo tiene subarbol izquierdo
	public boolean hasLeft() {
		return (left != null);
	}

	// Devuelve si el nodo tiene subarbol derecho
	public boolean hasRight() {
		return (right != null);
	}
	
	public void imprimirArbol() {
		if(isLeaf()) System.out.print("[ " + info + " ] ");
		else {
			System.out.print("[ " + info + " ");
			if(hasLeft()) left.imprimirArbol();
			else System.out.print("* ");
			if(hasRight()) right.imprimirArbol();
			else System.out.print("* ");
			System.out.print("] ");
		}		
	}

	public NodoABBEnteros borrarHojasMenoresQue(int num) {
		if(isLeaf() && info < num) return null;
		if(hasLeft()) left = left.borrarHojasMenoresQue(num);
		if(hasRight()) right = right.borrarHojasMenoresQue(num);
		return this;
	}
}