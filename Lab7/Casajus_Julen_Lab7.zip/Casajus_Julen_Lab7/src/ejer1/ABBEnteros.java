package ejer1;

public class ABBEnteros {
	
	NodoABBEnteros root;

	public ABBEnteros() {	
	}
	
	public boolean isEmpty() {
		return (root == null);
	}
	
	public void imprimirArbol() {
		if (isEmpty()) System.out.println("*");
		else {
			root.imprimirArbol();
			System.out.println();
		}
	}
	
	public void borrarHojasMenoresQue(int num) {
		if(!isEmpty()) {
			if(root.isLeaf() && root.info < num) root = null;
			else if(!root.isLeaf()) root.borrarHojasMenoresQue(num);
		}
	}
}