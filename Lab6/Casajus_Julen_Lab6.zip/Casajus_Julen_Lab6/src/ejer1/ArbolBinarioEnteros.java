package ejer1;

public class ArbolBinarioEnteros {
	
	NodoEnteros root;

	public ArbolBinarioEnteros() {
	}
	
	public boolean isEmpty() {
		return (root == null);
	}
	
	//Devuelve la suma de los nodos que estan en el nivel pasado como parametro
	public int sumarNivel(int nivelBuscado) {
		if(isEmpty()) return 0;
		return root.sumarNivel(nivelBuscado);
	}
}