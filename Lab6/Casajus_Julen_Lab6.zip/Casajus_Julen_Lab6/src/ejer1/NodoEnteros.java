package ejer1;

public class NodoEnteros {

	int info;
	NodoEnteros left;
	NodoEnteros right;

	public NodoEnteros(int info) {
		this.info = info;
	}

	// Devuelve si el nodo es hoja
	public boolean isLeaf() {
		return (left == null && right == null);
	}

	// Devuelve si el nodo tiene subarbol izquierdo
	public boolean hasLeft() {
		return (left != null);
	}

	// Devuelve si el nodo tiene subarbol derecho
	public boolean hasRight() {
		return (right != null);
	}
	
	public int sumarNivel(int nivelBuscado) {
		int sum = 0;
		if(nivelBuscado == 0) sum = info;
		else {
			if(hasLeft()) sum += left.sumarNivel(nivelBuscado -1);
			if(hasRight()) sum += right.sumarNivel(nivelBuscado -1);
		}
		return sum;
	}
}