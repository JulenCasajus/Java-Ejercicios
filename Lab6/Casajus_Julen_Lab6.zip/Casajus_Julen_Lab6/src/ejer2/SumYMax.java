package ejer2;

public class SumYMax<T extends Comparable<T>> {

	int sum;
	T max;
	
	public SumYMax(int sum, T max) {
		this.sum = sum;
		this.max = max;
	}

	public int getSum() {
		return sum;
	}

	public void setSum(int sum) {
		this.sum = sum;
	}

	public T getMax() {
		return max;
	}

	public void setMax(T max) {
		this.max = max;
	}
}