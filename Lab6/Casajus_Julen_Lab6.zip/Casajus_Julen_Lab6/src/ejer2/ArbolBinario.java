package ejer2;

public class ArbolBinario<T extends Comparable<T>> {
	
	Nodo<T> root;

	//Metodos basicos	
	public ArbolBinario() {
		this.root = null;
	}
	
	public ArbolBinario(T info) {
		this.root = new Nodo<T>(info);
	}


	public ArbolBinario(Nodo<T> root) {
		this.root = root;
	}

	public boolean isEmpty() {
		return (root == null);
	}
	
	public void imprimirArbol() {
		if (this.isEmpty())
			System.out.println("*");
		else {
			this.root.imprimirArbol();
			System.out.println();
		}
	}

	public int contarMayoresQueDescendientes() {
		if(isEmpty()) return 0;
		return root.contarMayoresQueDescendientes().getSum();
	}
}