package ejer3;

import java.util.LinkedList;

public class ArbolBinario<T> {
	
	Nodo<T> root;

	//Metodos basicos
	
	public ArbolBinario() {
		root = null;
	}
	
	public ArbolBinario(T info) {
		root = new Nodo<T>(info);
	}


	public ArbolBinario(Nodo<T> root) {
		this.root = root;
	}

	public boolean isEmpty() {
		return (root == null);
	}
	
	public void imprimirArbol() {
		if (isEmpty()) System.out.println("*");
		else {
			root.imprimirArbol();
			System.out.println();
		}
	}
	
	//Devuelve una lista con el camino desde la raiz hasta la hoja mas profunda.
	//En caso de empate, el camino que esta mas a la izquierda.	
	public LinkedList<T> caminoMasLargoHastaHoja(){
		if(isEmpty()) return new LinkedList<T>();
		return root.caminoMasLargoHastaHoja().lista;
	}
}