package ejer3;

import java.util.LinkedList;

public class ListaYAltura<T> {

	LinkedList<T> lista;
	int altura;
	
	public ListaYAltura(LinkedList<T> lista, int altura) {
		this.lista = lista;
		this.altura = altura;
	}

	public LinkedList<T> getLista() {
		return lista;
	}

	public void setLista(LinkedList<T> lista) {
		this.lista = lista;
	}
	
	public int getAltura() {
		return altura;
	}

	public void setAltura(int altura) {
		this.altura = altura;
	}
}