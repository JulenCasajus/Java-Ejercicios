package ejer3;

import java.util.LinkedList;

public class Nodo<T> {

	T info;
	Nodo<T> left;
	Nodo<T> right;

	// Metodos basicos

	public Nodo(T info) {
		this.info = info;
	}

	// Devuelve si el nodo es hoja
	public boolean isLeaf() {
		return (left == null && right == null);
	}

	// Devuelve si el nodo tiene subarbol izquierdo
	public boolean hasLeft() {
		return (left != null);
	}

	// Devuelve si el nodo tiene subarbol derecho
	public boolean hasRight() {
		return (right != null);
	}
	
	public void imprimirArbol() {
		if(this.isLeaf()) System.out.print("[ "+this.info+" ] ");
		else {
			System.out.print("[ "+info+" ");
			if(this.hasLeft()) this.left.imprimirArbol();
			else System.out.print("* ");
			if(this.hasRight()) this.right.imprimirArbol();
			else System.out.print("* ");
			System.out.print("] ");
		}		
	}
	
	public ListaYAltura<T> caminoMasLargoHastaHoja(){
		LinkedList<T> lista = new LinkedList<T>();
		ListaYAltura<T> LAL = new ListaYAltura<T>(lista, -1);
		ListaYAltura<T> LAR = new ListaYAltura<T>(lista, -1);
		
		lista.add(info);

		if(isLeaf()) {
			return new ListaYAltura<T>(lista, 0);
		}
		
		if(hasLeft()) LAL = left.caminoMasLargoHastaHoja();
		if(hasRight()) LAR = right.caminoMasLargoHastaHoja();
		
		if(LAL.altura < LAR.altura) {
			lista.addAll(LAR.lista);
			return new ListaYAltura<T>(lista, LAR.altura + 1);
		} lista.addAll(LAL.lista);
		return new ListaYAltura<T>(lista, LAL.altura + 1);
	}
}