package ejer4;

public class NodoEnteros {
	int info;
	NodoEnteros left;
	NodoEnteros right;
	int etiquetaNumHojas;

	public NodoEnteros(int info) {
		this.info = info;
	}

	// Devuelve si el nodo es hoja
	public boolean isLeaf() {
		return (left == null && right == null);
	}

	// Devuelve si el nodo tiene subarbol izquierdo
	public boolean hasLeft() {
		return (left != null);
	}

	// Devuelve si el nodo tiene subarbol derecho
	public boolean hasRight() {
		return (right != null);
	}
	
	public void imprimirEtiquetas() {
		System.out.println("Nodo " + info + ": etiquetaNumHojas=" + etiquetaNumHojas);
		if(hasLeft()) left.imprimirEtiquetas();
		if(hasRight()) right.imprimirEtiquetas();
	}
	
	public int etiquetar() {
		if(isLeaf()) etiquetaNumHojas = 1;
		if(hasLeft()) etiquetaNumHojas += left.etiquetar();
		if(hasRight()) etiquetaNumHojas += right.etiquetar();
		return etiquetaNumHojas;
	}
}