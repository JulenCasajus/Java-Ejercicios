package ejer4;

public class NodoEnteros {
	int info;
	NodoEnteros left;
	NodoEnteros right;
	int etiquetaNumHojas;

	public NodoEnteros(int info) {
		this.info = info;
	}

	// Devuelve si el nodo es hoja
	public boolean isLeaf() {
		return (left == null && right == null);
	}

	// Devuelve si el nodo tiene sub�rbol izquierdo
	public boolean hasLeft() {
		return (left != null);
	}

	// Devuelve si el nodo tiene sub�rbol derecho
	public boolean hasRight() {
		return (right != null);
	}
	
	public void imprimirEtiquetas() {
		System.out.println("Nodo "+this.info+": etiquetaNumHojas="+this.etiquetaNumHojas);
		if(this.hasLeft()) this.left.imprimirEtiquetas();
		if(this.hasRight()) this.right.imprimirEtiquetas();
	}
	
	//EJERCICIO 4: etiquetar
	  //TO DO
	
 

}
