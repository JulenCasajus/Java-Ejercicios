package ejer4;

public class ArbolBinarioEnteros {
	
	NodoEnteros root;

	public ArbolBinarioEnteros() {
		
	}
	
	public boolean isEmpty() {
		return (root == null);
	}
	
	
	public void imprimirEtiquetas() {
		if(!this.isEmpty()) this.root.imprimirEtiquetas();
	}
	
	
	
	public void etiquetar() {
		
		//TO DO
	}

}
